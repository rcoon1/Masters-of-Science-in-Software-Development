// Mobile navigation
const menu = document.querySelector(".menu"),
  nav = document.querySelector("nav");
menu.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menu.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach((a) =>
  a.addEventListener("click", () => {
    nav.classList.remove("open");
    menu.setAttribute("aria-expanded", "false");
  }),
);
// Select a service in the estimate form.
document.querySelectorAll("[data-service]").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelector("#service").value = b.dataset.service;
    document.querySelector("#estimate").scrollIntoView({
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
    });
  }),
);
// Footer date and estimate request preparation
document.querySelector("#year").textContent = new Date().getFullYear();
document.querySelector("#quote").addEventListener("submit", (e) => {
  e.preventDefault();
  const d = new FormData(e.target);
  const message = `Hi Lawn Ranger & Pronto! I'd like a free estimate.\nName: ${d.get("name")}\nArea: ${d.get("city")}\nService: ${d.get("service")}\nProject: ${d.get("details")}`;
  document.querySelector("#message").value = message;
  document.querySelector("#sms").href =
    "sms:+13619477839?body=" + encodeURIComponent(message);
  document.querySelector("#request").hidden = false;
  document.querySelector("#status").textContent =
    "Request prepared. Open your messaging app or copy it and text (361) 947-7839.";
});
document.querySelector("#copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(
      document.querySelector("#message").value,
    );
    document.querySelector("#status").textContent =
      "Copied. Paste into a text to (361) 947-7839.";
  } catch {
    document.querySelector("#message").select();
    document.querySelector("#status").textContent =
      "Select and copy the prepared request above.";
  }
});

// Gallery assets and original YouTube video IDs
const projectPhotos = [
  "01.jpg",
  "02.jpg",
  "03.jpg",
  "04.jpg",
  "05.jpg",
  "06.jpg",
  "07.png",
  "08.jpg",
  "09.jpg",
  "10.jpg",
  "11.jpg",
  "12.jpg",
  "13.jpg",
  "14.jpg",
  "15.jpg",
  "16.jpg",
  "17.jpg",
];
const workVideos = [
  "CMpLdvTjugU",
  "V6XkTs445rA",
  "oSel26mimBU",
  "aP7Mmu4ECkE",
  "88dceM9HkTg",
  "9D2uMO-JhKQ",
  "UuJV9d_saHM",
  "epBVbWDscVE",
  "WOfDl4x072E",
  "DI765PNIvuQ",
  "PL0LnVtra4A",
  "pVZDgSfif1w",
  "ZhikoerS6vg",
];

// Full-size project viewer: open, close, and keyboard navigation
const photoGrid = document.querySelector("#gallery-grid"),
  viewer = document.querySelector("#lightbox");
let activePhoto = 0,
  lastPhotoButton;
function displayPhoto(i) {
  activePhoto = (i + projectPhotos.length) % projectPhotos.length;
  document.querySelector("#full-photo").src =
    "assets/gallery/" + projectPhotos[activePhoto];
  document.querySelector("#full-photo").alt =
    "Project collection photo " + (activePhoto + 1);
  document.querySelector("#photo-position").textContent =
    `Photo ${activePhoto + 1} of ${projectPhotos.length}`;
}
projectPhotos.forEach((file, i) => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "gallery-item";
  button.hidden = i >= 6;
  button.setAttribute("aria-label", `View project photo ${i + 1} full size`);
  button.innerHTML = `<img src="assets/gallery/${file}" alt="Project collection photo ${i + 1}" loading="lazy"><span class="gallery-caption">Project photo ${String(i + 1).padStart(2, "0")} <span aria-hidden="true">↗</span></span>`;
  button.addEventListener("click", () => {
    lastPhotoButton = button;
    displayPhoto(i);
    viewer.showModal();
  });
  photoGrid.append(button);
});
document
  .querySelector("#close-photo")
  .addEventListener("click", () => viewer.close());
viewer.addEventListener("close", () => lastPhotoButton?.focus());
viewer.addEventListener("click", (e) => {
  if (e.target === viewer) {
    const r = viewer.getBoundingClientRect();
    if (
      e.clientX < r.left ||
      e.clientX > r.right ||
      e.clientY < r.top ||
      e.clientY > r.bottom
    )
      viewer.close();
  }
});
document
  .querySelector("#previous-photo")
  .addEventListener("click", () => displayPhoto(activePhoto - 1));
document
  .querySelector("#next-photo")
  .addEventListener("click", () => displayPhoto(activePhoto + 1));
viewer.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight") {
    e.preventDefault();
    displayPhoto(activePhoto + 1);
  }
  if (e.key === "ArrowLeft") {
    e.preventDefault();
    displayPhoto(activePhoto - 1);
  }
});

// Create video cards; load a player only after the visitor selects it.
const videoGrid = document.querySelector("#video-grid");
workVideos.forEach((id, i) => {
  const card = document.createElement("article");
  card.className = "video-card";
  card.hidden = i >= 3;
  card.innerHTML = `<div class="video-frame"><button type="button" class="video-play" aria-label="Play work video ${i + 1}"><img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="" loading="lazy"><span class="play-symbol" aria-hidden="true">▶</span></button></div><div class="video-caption"><h3>In the field · ${String(i + 1).padStart(2, "0")}</h3><a href="https://www.youtube.com/watch?v=${id}" target="_blank" rel="noopener">Open on YouTube ↗</a></div>`;
  card.querySelector(".video-play").addEventListener("click", () => {
    // Local files cannot supply the HTTP referrer required by YouTube.
    if (!["http:", "https:"].includes(window.location.protocol)) {
      window.open(
        `https://www.youtube.com/watch?v=${id}`,
        "_blank",
        "noopener",
      );
      return;
    }

    const iframe = document.createElement("iframe");
    iframe.referrerPolicy = "strict-origin-when-cross-origin";
    const playerUrl = new URL(`https://www.youtube-nocookie.com/embed/${id}`);
    playerUrl.searchParams.set("autoplay", "1");
    playerUrl.searchParams.set("playsinline", "1");
    playerUrl.searchParams.set("origin", window.location.origin);
    iframe.src = playerUrl.href;
    iframe.title = `The Lawn Ranger & Pronto — work video ${i + 1}`;
    iframe.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
    iframe.allowFullscreen = true;
    card.querySelector(".video-frame").replaceChildren(iframe);
  });
  videoGrid.append(card);
});

// Expand and collapse the photo and video collections.
function collectionToggle(
  button,
  container,
  limit,
  expandedText,
  collapsedText,
) {
  button.addEventListener("click", () => {
    const expanded = button.getAttribute("aria-expanded") !== "true";
    button.setAttribute("aria-expanded", String(expanded));
    Array.from(container.children).forEach((item, i) => {
      item.hidden = !expanded && i >= limit;
      if (item.hidden) {
        const frame = item.querySelector("iframe");
        if (frame) frame.src = frame.src.replace("autoplay=1", "autoplay=0");
      }
    });
    button.textContent = expanded ? expandedText : collapsedText;
    if (!expanded)
      container.parentElement.scrollIntoView({
        behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "auto"
          : "smooth",
      });
  });
}
collectionToggle(
  document.querySelector("#gallery-toggle"),
  photoGrid,
  6,
  "Show fewer photos ↑",
  "View all project photos ↓",
);
collectionToggle(
  document.querySelector("#video-toggle"),
  videoGrid,
  3,
  "Show fewer videos ↑",
  "Explore all videos ↓",
);
