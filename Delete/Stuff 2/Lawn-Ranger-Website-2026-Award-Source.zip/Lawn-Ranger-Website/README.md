# The Lawn Ranger & Pronto Services

Updated website source including the original logo, 17 project photos with a full-size gallery, and 13 embedded YouTube videos.

## Run in Visual Studio Code
1. Extract this ZIP.
2. Choose File > Open Folder in VS Code and open Lawn-Ranger-Website.
3. Open index.html with the Live Server extension, or open index.html directly in a browser.

Optional: run `python -m http.server 8000` from this folder, then visit http://localhost:8000.
No Docker, Node.js, database, or build step is required.

## Edit
- index.html: page content and sections
- style.css: colors, typography, responsive layout
- app.js: navigation, estimate requests, gallery viewer, and video players
- assets/background.jpg: original logo
- assets/gallery/: all 17 project photos

The projectPhotos and workVideos arrays in app.js control the gallery and video collection.

## Behavior and requirements
The estimate form prepares an SMS for the visitor to review and send; there is no backend submission. Clipboard access may require localhost or HTTPS. Videos, thumbnails, and Google Fonts require internet access. Videos load only after selection. Playback depends on YouTube availability and embedding permissions.

## Publish
Upload the contents of this folder to any static website host. No build step is necessary.

## Source formatting and logo sizes
HTML, CSS, and JavaScript use consistent two-space indentation. JavaScript sections include comments.
The original logo is 240px wide on desktop, 220px on tablets, 170px on phones, and 200px in the mobile footer. Its aspect ratio is preserved.
To format future edits, run `npx prettier --write index.html style.css app.js` (optional; Node.js required only for this formatting command).

## 2026 recognition
The site includes the supplied Corpus Christi Community’s Choice Awards SVG and the business-provided 2026 Best Lawn Care/Landscaping Company recognition. The SVG is stored in assets/corpus-christi-choice-awards.svg.
