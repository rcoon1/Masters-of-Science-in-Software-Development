-- Run as a MySQL administrator, once, using MySQL Workbench or mysql CLI.
-- Replace CHANGE_ME with your own password before executing.
CREATE DATABASE IF NOT EXISTS byte_bazaar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'bytebazaar'@'localhost' IDENTIFIED BY 'CHANGE_ME';
GRANT ALL PRIVILEGES ON byte_bazaar.* TO 'bytebazaar'@'localhost';
-- If the user already exists, change its password separately with ALTER USER.
-- Spring Boot applies the table migrations and seed data on first startup.
