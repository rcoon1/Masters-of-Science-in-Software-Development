# Byte Bazaar — VS Code edition

React frontend · Spring Boot REST API · MySQL database. No Docker required.

## 1. Install prerequisites (one time)

- Visual Studio Code
- JDK 17 or newer compatible JDK (JDK 17 is the tested language target)
- Apache Maven 3.9.x
- Node.js 22 LTS with npm
- MySQL Server 8.4 (MySQL Workbench is optional but convenient)

On Windows, make sure the installers add Java, Maven, and Node to PATH. Open a new terminal and check `java -version`, `mvn -version`, and `node -v`. VS Code's Java extension is not a replacement for a local JDK; these tasks also require Maven on PATH.

## 2. Open the project

Extract the ZIP and use **File → Open Folder** to open the `byte-bazaar` folder that contains `.vscode`, `backend`, and `frontend`. Install the recommended Java, Spring Boot, and Prettier extensions when prompted. Allow the Java extension to finish importing the Maven project.

## 3. Configure local MySQL

Start the MySQL service. In MySQL Workbench, connect as an administrator, open `database/setup.sql`, replace `CHANGE_ME` with your chosen password, and execute the script. It creates the `byte_bazaar` database and a database-specific application user. Do not run the application as the MySQL root user.

Copy `backend/config/application-local.example.properties` to `backend/config/application-local.properties`. Replace `CHANGE_ME` with the same password. This real configuration file is ignored by Git. MySQL defaults to localhost port 3306; adjust the connection URL if your installation uses another port.

The setup SQL creates the database and user only. Spring Boot automatically runs the Flyway table migration and adds sample listings on first startup. Existing project databases retain their data; this update does not change the migration schema.

## 4. Install frontend dependencies

In VS Code select **Terminal → Run Task → Frontend: install**. Wait for it to finish. Alternatively:

```sh
cd frontend
npm ci
```

## 5. Start the application

Select **Terminal → Run Task → Start Byte Bazaar**. Two terminal tasks start in parallel:

- Spring Boot API: http://localhost:8080
- React application: **http://localhost:5173**

Wait for the backend's “Started Application” message, then open the React URL and create an account. If the frontend opens before the API is ready, refresh it after the backend starts. Data is stored in your local MySQL database.

To stop, use **Terminal → Terminate Task** for both tasks, or press Ctrl+C in each terminal. MySQL runs independently as a local service.

### Manual terminal commands

Open two VS Code terminals. In the first:

```sh
cd backend
mvn spring-boot:run
```

In the second:

```sh
cd frontend
npm run dev
```

### Debugging with F5

For Java breakpoints, start only the frontend task, then select **Debug Spring Boot API** in Run and Debug and press F5. Do not also run the Backend: start task, because both would try to use port 8080. With the frontend task running, **Debug Byte Bazaar** starts the API debugger and Chrome together. The standalone **Debug React in Chrome** profile works with both servers already running.

## Project organization

- `backend/src/main/java/com/bytebazaar/*Controller.java`: HTTP routes grouped by accounts, listings, orders/bookings, and community.
- `MarketplaceService.java`: transactional business logic and persistence access.
- `Requests.java`: validated API request records.
- `ApiExceptionHandler.java`: shared API error responses.
- Entity files and `Security.java`: persisted data models and session/CSRF security.
- `backend/src/main/resources/db/migration`: versioned MySQL schema and seed content.
- `frontend/src/App.jsx`: page state and orchestration.
- `frontend/src/components`: hero, footer, and marketplace dialogs.
- `frontend/src/lib`: API transport and currency formatting.
- `.vscode`: tasks, debugger settings, and extension recommendations.
- `tests/smoke.py`: integration checks against the running local stack.

The frontend proxies `/api` to the Spring Boot API, keeping browser cookies and CSRF requests on the same origin. Call the application through port 5173 during development. The dev servers bind to loopback for local use.

## Included features

Marketplace search and filters; accounts; seller listing creation; shopping bag and atomic demo checkout; order history; auction bids with closing-time checks; service requests; community topics and replies. Passwords are hashed with BCrypt. MySQL uses Flyway migrations and database relationships.

## Prototype boundaries

Checkout creates demo records and reserves stock; it does not charge money. Digital files/licenses are not delivered. Bookings are requests rather than confirmed reservations. Auctions record bids but do not automatically settle winners. Messaging, reviews, moderation/admin, seller editing, MFA, refunds, NFTs, and recommendations remain future work. This is an MVP, not a production-ready marketplace.

## Checks and formatting

Frontend: `npm run build`, `npm run format:check`, or `npm run format` from `frontend`. Backend: `mvn verify` from `backend`. Integration: with both servers and MySQL running, execute `py tests/smoke.py` on Windows or `python3 tests/smoke.py` elsewhere. The script creates development test records.

See `VERIFICATION.md` for the checks actually run here.

## Troubleshooting

- `mvn` or `java` not recognized: check PATH and JAVA_HOME, then restart VS Code.
- Access denied by MySQL: verify the local properties password matches the MySQL user, and that MySQL is running.
- Unknown database: execute `database/setup.sql` as an administrator first.
- Port 8080 in use: stop the old API/debug session. Port 5173 in use: stop the old frontend task.
- Missing backend configuration: ensure the real properties file is inside `backend/config`, not only the example file.
- Dependencies cannot download: check your network/proxy configuration. No Docker image or container is needed.
