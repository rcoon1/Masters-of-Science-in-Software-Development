# VS Code edition verification

Passed: React production build after component refactor (29 modules); frontend formatting check; Java syntax parsing via prettier-plugin-java; XML/JSON parsing for Maven and VS Code configuration.

Not verified: Java compilation, MySQL migrations, VS Code execution/debug sessions, browser UI navigation, or end-to-end flows. The creation environment has no local MySQL, and backend Maven dependency access was blocked. No claim of a fully tested runtime is made.

To complete local checks, install the prerequisites in README.md, execute database/setup.sql, configure backend/config/application-local.properties, run Start Byte Bazaar in VS Code, and execute tests/smoke.py. The script exercises CSRF rejection, registration, sessions, seller listing creation, checkout, stock rejection, bids, service requests, and forum topics/replies using the actual API and MySQL. It creates test records, so use a development database.
