package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "bids")
public class Bid {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public Long listingId;
  public Long bidderId;

  @Column(precision = 12, scale = 2)
  public java.math.BigDecimal amount;

  public java.time.Instant createdAt;
}
