package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "listings")
public class Listing {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public String title;
  public String description;
  public String category;
  public String kind;

  @Column(precision = 12, scale = 2)
  public java.math.BigDecimal price;

  public Long sellerId;
  public Integer stock;
  public java.time.Instant endsAt;
}
