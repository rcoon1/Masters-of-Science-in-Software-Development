package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class Booking {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public Long listingId;
  public Long buyerId;
  public String notes;
  public java.time.LocalDate scheduledDate;
  public String status;
}
