package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "replies")
public class Reply {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public Long topicId;
  public Long authorId;
  public String author;
  public String body;
  public java.time.Instant createdAt;
}
