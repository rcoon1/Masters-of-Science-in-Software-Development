package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "topics")
public class Topic {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public Long authorId;
  public String author;
  public String title;
  public String body;
  public java.time.Instant createdAt;
}
