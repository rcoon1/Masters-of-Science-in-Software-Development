package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public String name;
  public String email;

  @com.fasterxml.jackson.annotation.JsonIgnore
  public String password;
}
