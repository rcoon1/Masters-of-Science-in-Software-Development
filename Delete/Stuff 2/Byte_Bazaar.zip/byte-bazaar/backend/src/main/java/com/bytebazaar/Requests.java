package com.bytebazaar;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

public final class Requests {

  private Requests() {}

  public record Credentials(
    @NotBlank @Email String email,
    @NotBlank @Size(min = 8, max = 72) String password,
    String name
  ) {}

  public record ListingInput(
    @NotBlank @Size(max = 255) String title,
    @NotBlank @Size(max = 255) String description,
    @NotBlank String category,
    @NotBlank String kind,
    @NotNull @DecimalMin("0.01") @Digits(
      integer = 10,
      fraction = 2
    ) BigDecimal price,
    @NotNull @Min(1) Integer stock,
    Instant endsAt
  ) {}

  public record Checkout(@NotEmpty List<Long> listingIds) {}

  public record Amount(
    @NotNull @DecimalMin("0.01") @Digits(
      integer = 10,
      fraction = 2
    ) BigDecimal amount
  ) {}

  public record BookingInput(
    @NotNull Long listingId,
    @NotNull @Future LocalDate scheduledDate,
    @NotBlank @Size(max = 255) String notes
  ) {}

  public record TopicInput(
    @NotBlank @Size(max = 255) String title,
    @NotBlank @Size(max = 255) String body
  ) {}

  public record ReplyInput(@NotBlank @Size(max = 255) String body) {}
}
