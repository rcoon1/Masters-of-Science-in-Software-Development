package com.bytebazaar;

import jakarta.persistence.*;

@Entity
@Table(name = "purchases")
public class Purchase {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  public Long buyerId;
  public Long listingId;
  public String title;

  @Column(precision = 12, scale = 2)
  public java.math.BigDecimal total;

  public String status;
  public java.time.Instant createdAt;
}
