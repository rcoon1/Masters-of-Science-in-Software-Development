package com.bytebazaar;

import static com.bytebazaar.Requests.*;

import jakarta.persistence.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.time.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@org.springframework.stereotype.Service
@Transactional
public class MarketplaceService {

  @PersistenceContext
  private EntityManager entityManager;

  private final BCryptPasswordEncoder encoder;

  public MarketplaceService(BCryptPasswordEncoder encoder) {
    this.encoder = encoder;
  }

  ResponseStatusException fail(String m) {
    return new ResponseStatusException(HttpStatus.BAD_REQUEST, m);
  }

  Account requireUser(HttpSession s) {
    Object id = s.getAttribute("uid");
    if (id == null) throw new ResponseStatusException(
      HttpStatus.UNAUTHORIZED,
      "Please sign in"
    );
    return entityManager.find(Account.class, (Long) id);
  }

  Listing lockListing(Long id) {
    Listing l = entityManager.find(
      Listing.class,
      id,
      LockModeType.PESSIMISTIC_WRITE
    );
    if (l == null) throw new ResponseStatusException(
      HttpStatus.NOT_FOUND,
      "Listing not found"
    );
    return l;
  }

  <T> T persist(T o) {
    entityManager.persist(o);
    return o;
  }

  public Map<String, String> csrf(CsrfToken token) {
    return Map.of("token", token.getToken());
  }

  public Account register(Credentials c, HttpServletRequest request) {
    if (
      c.name() == null || c.name().isBlank() || c.name().length() > 100
    ) throw fail("Enter a name of up to 100 characters");
    if (
      !entityManager
        .createQuery("from Account where email=:e", Account.class)
        .setParameter("e", c.email().toLowerCase(Locale.ROOT))
        .getResultList()
        .isEmpty()
    ) throw fail("Email already registered");
    Account a = new Account();
    a.name = c.name();
    a.email = c.email().toLowerCase(Locale.ROOT);
    a.password = encoder.encode(c.password());
    persist(a);
    request.getSession();
    request.changeSessionId();
    request.getSession().setAttribute("uid", a.id);
    return a;
  }

  public Account login(Credentials c, HttpServletRequest request) {
    var found = entityManager
      .createQuery("from Account where email=:e", Account.class)
      .setParameter("e", c.email().toLowerCase(Locale.ROOT))
      .getResultList();
    if (
      found.isEmpty() || !encoder.matches(c.password(), found.get(0).password)
    ) throw new ResponseStatusException(
      HttpStatus.UNAUTHORIZED,
      "Incorrect email or password"
    );
    request.getSession();
    request.changeSessionId();
    request.getSession().setAttribute("uid", found.get(0).id);
    return found.get(0);
  }

  public void logout(HttpSession s) {
    s.invalidate();
  }

  public Account me(HttpSession s) {
    return requireUser(s);
  }

  public List<Listing> listings() {
    return entityManager
      .createQuery("from Listing order by id desc", Listing.class)
      .getResultList();
  }

  public Listing create(ListingInput d, HttpSession s) {
    Account a = requireUser(s);
    if (
      !Set.of("SALE", "AUCTION", "SERVICE", "DIGITAL").contains(d.kind())
    ) throw fail("Invalid listing type");
    if (
      d.kind().equals("AUCTION") &&
      (d.endsAt() == null || !d.endsAt().isAfter(Instant.now()))
    ) throw fail("Choose a future auction closing time");
    Listing l = new Listing();
    l.title = d.title();
    l.description = d.description();
    l.category = d.category();
    l.kind = d.kind();
    l.price = d.price();
    l.stock = d.stock();
    l.endsAt = d.endsAt();
    l.sellerId = a.id;
    return persist(l);
  }

  public List<Purchase> orders(HttpSession s) {
    return entityManager
      .createQuery(
        "from Purchase where buyerId=:u order by id desc",
        Purchase.class
      )
      .setParameter("u", requireUser(s).id)
      .getResultList();
  }

  public List<Purchase> checkout(Checkout d, HttpSession s) {
    Account a = requireUser(s);
    if (
      d.listingIds().size() > 50 ||
      new HashSet<>(d.listingIds()).size() != d.listingIds().size()
    ) throw fail("Use at most 50 distinct listings");
    List<Purchase> result = new ArrayList<>();
    for (Long id : d.listingIds().stream().sorted().toList()) {
      Listing l = lockListing(id);
      if (
        !Set.of("SALE", "DIGITAL").contains(l.kind) ||
        l.stock < 1 ||
        l.sellerId.equals(a.id)
      ) throw fail("Item unavailable or belongs to you");
      l.stock--;
      Purchase p = new Purchase();
      p.buyerId = a.id;
      p.listingId = id;
      p.title = l.title;
      p.total = l.price;
      p.status = "DEMO_ORDER";
      p.createdAt = Instant.now();
      result.add(persist(p));
    }
    return result;
  }

  public List<Bid> bids(Long id) {
    return entityManager
      .createQuery(
        "from Bid where listingId=:id order by amount desc",
        Bid.class
      )
      .setParameter("id", id)
      .getResultList();
  }

  public Bid bid(Long id, Amount d, HttpSession s) {
    Account a = requireUser(s);
    Listing l = lockListing(id);
    if (
      !l.kind.equals("AUCTION") ||
      l.endsAt == null ||
      !l.endsAt.isAfter(Instant.now()) ||
      a.id.equals(l.sellerId)
    ) throw fail("Bidding unavailable");
    if (d.amount().compareTo(l.price) <= 0) throw fail(
      "Bid must exceed the current price"
    );
    l.price = d.amount();
    Bid b = new Bid();
    b.listingId = id;
    b.bidderId = a.id;
    b.amount = d.amount();
    b.createdAt = Instant.now();
    return persist(b);
  }

  public Booking book(BookingInput d, HttpSession s) {
    Account a = requireUser(s);
    Listing l = lockListing(d.listingId());
    if (!l.kind.equals("SERVICE") || l.sellerId.equals(a.id)) throw fail(
      "Service unavailable"
    );
    Booking b = new Booking();
    b.listingId = l.id;
    b.buyerId = a.id;
    b.scheduledDate = d.scheduledDate();
    b.notes = d.notes();
    b.status = "REQUESTED";
    return persist(b);
  }

  public List<Booking> bookings(HttpSession s) {
    return entityManager
      .createQuery(
        "from Booking where buyerId=:u order by id desc",
        Booking.class
      )
      .setParameter("u", requireUser(s).id)
      .getResultList();
  }

  public List<Topic> topics() {
    return entityManager
      .createQuery("from Topic order by id desc", Topic.class)
      .getResultList();
  }

  public Topic topic(TopicInput d, HttpSession s) {
    Account a = requireUser(s);
    Topic t = new Topic();
    t.authorId = a.id;
    t.author = a.name;
    t.title = d.title();
    t.body = d.body();
    t.createdAt = Instant.now();
    return persist(t);
  }

  public List<Reply> replies(Long id) {
    return entityManager
      .createQuery("from Reply where topicId=:id order by id", Reply.class)
      .setParameter("id", id)
      .getResultList();
  }

  public Reply reply(Long id, ReplyInput d, HttpSession s) {
    Account a = requireUser(s);
    if (
      entityManager.find(Topic.class, id) == null
    ) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    Reply r = new Reply();
    r.topicId = id;
    r.authorId = a.id;
    r.author = a.name;
    r.body = d.body();
    r.createdAt = Instant.now();
    return persist(r);
  }
}
