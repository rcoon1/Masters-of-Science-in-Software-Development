"""Integration checks against a running local frontend and API; Python standard library only."""
import json, urllib.request, urllib.error, http.cookiejar, uuid, datetime
base="http://localhost:5173/api"
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
token=None
def call(path, method="GET", body=None, status=200, csrf=True):
    headers={"Content-Type":"application/json"}
    if method!="GET" and csrf: headers["X-XSRF-TOKEN"]=token
    req=urllib.request.Request(base+path, data=json.dumps(body).encode() if body is not None else None, method=method, headers=headers)
    try:
        with client.open(req) as res: code=res.status; raw=res.read()
    except urllib.error.HTTPError as e: code=e.code; raw=e.read()
    assert code==status, (path,code,raw.decode())
    return json.loads(raw) if raw else None
token=call("/csrf")["token"]
call("/auth/register","POST",{},status=403,csrf=False)
suffix=uuid.uuid4().hex[:12]
creds={"email":suffix+"@example.com","password":"test-strong-password","name":"Smoke test"}
me=call("/auth/register","POST",creds)
assert "password" not in me
assert call("/auth/me")["id"]==me["id"]
listing=call("/listings","POST",{"title":"Smoke item","description":"Integration check","category":"Hardware","kind":"SALE","price":12.50,"stock":1})
call("/auth/logout","POST")
token=call("/csrf")["token"]
creds2={**creds,"email":"buyer-"+creds["email"]}
call("/auth/register","POST",creds2)
order=call("/orders","POST",{"listingIds":[listing["id"]]})
assert order[0]["total"]==12.5
call("/orders","POST",{"listingIds":[listing["id"]]},status=400)
assert len(call("/orders"))==1
items=call("/listings")
auction=next(i for i in items if i["kind"]=="AUCTION")
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":float(auction["price"])+1})
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":auction["price"]},status=400)
service=next(i for i in items if i["kind"]=="SERVICE")
call("/bookings","POST",{"listingId":service["id"],"scheduledDate":str(datetime.date.today()+datetime.timedelta(days=3)),"notes":"Smoke request"})
assert call("/bookings")
topic=call("/topics","POST",{"title":"Smoke "+suffix,"body":"Forum integration check"})
call("/topics/"+str(topic["id"])+"/replies","POST",{"body":"Reply check"})
assert len(call("/topics/"+str(topic["id"])+"/replies"))==1
print("PASS: registration, CSRF, sessions, checkout, stock, bids, bookings, forum")
