import React from "react";
export default function Hero() {
  return (
    <section className="hero">
      <div>
        <span className="eyebrow">THE MARKETPLACE FOR WHAT’S NEXT</span>
        <h1>
          Good tech.
          <br />
          Great possibilities.
        </h1>
        <p>
          Discover hardware, digital essentials, and people
          <br className="desktop" /> who can help bring your next big idea to
          life.
        </p>
        <button
          className="dark"
          onClick={() =>
            document
              .getElementById("catalog")
              .scrollIntoView({ behavior: "smooth" })
          }
        >
          Find your next thing <span>↗</span>
        </button>
        <div className="hero-foot">
          <span>↗ Built for the curious.</span>
          <span>Made for the creators.</span>
        </div>
      </div>
      <div
        className="art"
        aria-label="Abstract illustration of a computer workspace"
      >
        <div className="orbit o1" />
        <div className="orbit o2" />
        <div className="floating">
          A LITTLE UPGRADE.
          <br />
          <strong>A lot of potential.</strong>
        </div>
        <div className="monitor">
          <div className="screen">
            <span>hello, world_</span>
            <div className="code">
              &lt;create&gt;
              <br />
              &nbsp; something amazing
              <br />
              &lt;/create&gt;
            </div>
            <div className="screen-dot" />
          </div>
          <div className="stand" />
        </div>
        <div className="keyboard">
          {Array.from({ length: 30 }, (_, i) => (
            <i key={i} />
          ))}
        </div>
        <div className="chip">
          BB
          <br />
          <small>IDEAS INSIDE</small>
        </div>
        <span className="art-label">YOUR NEXT CHAPTER STARTS HERE ↗</span>
      </div>
    </section>
  );
}
