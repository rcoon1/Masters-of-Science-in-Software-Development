import React from "react";
import { api } from "../lib/api";
import { money } from "../lib/format";
export default function MarketplaceDialog({
  modal,
  setModal,
  error,
  user,
  cart,
  setCart,
  run,
  form,
  setUser,
  setNotice,
  refresh,
  setReplies,
  replies,
  busy,
  open,
}) {
  return (
    <div className="overlay" onClick={() => setModal(null)}>
      <section
        role="dialog"
        aria-modal="true"
        aria-label="Marketplace dialog"
        className="modal"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="close"
          aria-label="Close dialog"
          onClick={() => setModal(null)}
        >
          ×
        </button>
        {error && (
          <p className="alert" role="alert">
            {error}
          </p>
        )}
        {["login", "register"].includes(modal.type) && (
          <>
            <span className="eyebrow">WELCOME TO BYTE BAZAAR</span>
            <h2>
              {modal.type === "login"
                ? "Good to see you."
                : "Find your people."}
            </h2>
            <form
              onSubmit={(e) =>
                form(e, async (d) => {
                  setUser(await api("/auth/" + modal.type, "POST", d));
                  setModal(null);
                  setNotice("You’re signed in. Welcome to the bazaar.");
                })
              }
            >
              {modal.type === "register" && (
                <label>
                  Name
                  <input
                    name="name"
                    maxLength="100"
                    required
                    autoComplete="name"
                  />
                </label>
              )}
              <label>
                Email
                <input
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                />
              </label>
              <label>
                Password
                <input
                  name="password"
                  type="password"
                  minLength="8"
                  maxLength="72"
                  required
                  autoComplete={
                    modal.type === "login" ? "current-password" : "new-password"
                  }
                />
              </label>
              <button className="dark" disabled={busy}>
                {busy
                  ? "Please wait…"
                  : modal.type === "login"
                    ? "Sign in"
                    : "Create account"}
              </button>
            </form>
            <button
              onClick={() =>
                open({ type: modal.type === "login" ? "register" : "login" })
              }
            >
              {modal.type === "login"
                ? "New here? Create an account"
                : "Already a member? Sign in"}
            </button>
          </>
        )}
        {modal.type === "detail" && (
          <>
            <span className="eyebrow">
              {modal.item.kind} · {modal.item.category}
            </span>
            <h2>{modal.item.title}</h2>
            <p>{modal.item.description}</p>
            <h2>{money(modal.item.price)}</h2>
            {modal.item.kind === "AUCTION" && (
              <p>
                Closes {new Date(modal.item.endsAt).toLocaleString()}. Bids are
                demo records; winner settlement is not implemented.
              </p>
            )}
            {modal.item.kind === "SERVICE" ? (
              <form
                onSubmit={(e) =>
                  form(e, async (d) => {
                    await api("/bookings", "POST", {
                      ...d,
                      listingId: modal.item.id,
                    });
                    setModal(null);
                    setNotice(
                      "Service request submitted. View it in your dashboard.",
                    );
                  })
                }
              >
                <label>
                  Requested date
                  <input
                    name="scheduledDate"
                    type="date"
                    min={new Date(Date.now() + 86400000)
                      .toISOString()
                      .slice(0, 10)}
                    required
                  />
                </label>
                <label>
                  Project notes
                  <textarea name="notes" maxLength="255" required />
                </label>
                <button className="dark" disabled={busy}>
                  Request booking
                </button>
              </form>
            ) : modal.item.kind === "AUCTION" ? (
              <form
                onSubmit={(e) =>
                  form(e, async (d) => {
                    await api("/listings/" + modal.item.id + "/bids", "POST", {
                      amount: Number(d.amount),
                    });
                    await refresh();
                    setModal(null);
                    setNotice("Your bid was recorded.");
                  })
                }
              >
                <label>
                  Your bid
                  <input
                    type="number"
                    name="amount"
                    min={Number(modal.item.price) + 0.01}
                    step=".01"
                    required
                  />
                </label>
                <button
                  className="dark"
                  disabled={busy || new Date(modal.item.endsAt) <= new Date()}
                >
                  Place bid
                </button>
              </form>
            ) : (
              <button
                className="dark"
                disabled={modal.item.stock < 1}
                onClick={() => {
                  setCart((c) =>
                    c.some((i) => i.id === modal.item.id)
                      ? c
                      : [...c, modal.item],
                  );
                  setModal(null);
                  setNotice("Added to your bag.");
                }}
              >
                Add to bag +
              </button>
            )}
            {!user && (
              <p>Sign in before placing bids or requesting services.</p>
            )}
          </>
        )}
        {modal.type === "cart" && (
          <>
            <h2>Your bag.</h2>
            {cart.map((i) => (
              <div className="row" key={i.id}>
                <span>{i.title}</span>
                <strong>{money(i.price)}</strong>
                <button
                  aria-label={"Remove " + i.title}
                  onClick={() => setCart(cart.filter((x) => x.id !== i.id))}
                >
                  ×
                </button>
              </div>
            ))}
            {!cart.length ? (
              <p>Your bag is waiting for a good find.</p>
            ) : (
              <>
                <h3>
                  Total {money(cart.reduce((s, i) => s + Number(i.price), 0))}
                </h3>
                <p>
                  Demo checkout creates order records and reserves stock. No
                  money is charged and no files are delivered.
                </p>
                <button
                  className="dark"
                  disabled={busy}
                  onClick={() =>
                    user
                      ? run(async () => {
                          await api("/orders", "POST", {
                            listingIds: cart.map((i) => i.id),
                          });
                          setCart([]);
                          setModal(null);
                          await refresh();
                          setNotice(
                            "Demo order created. View it in your dashboard.",
                          );
                        })
                      : open({ type: "login" })
                  }
                >
                  {user ? "Create demo order" : "Sign in to continue"}
                </button>
              </>
            )}
          </>
        )}
        {modal.type === "sell" && (
          <>
            <h2>Make your next listing.</h2>
            <form
              onSubmit={(e) =>
                form(e, async (d) => {
                  await api("/listings", "POST", {
                    ...d,
                    price: Number(d.price),
                    stock: Number(d.stock),
                    endsAt: d.endsAt ? new Date(d.endsAt).toISOString() : null,
                  });
                  await refresh();
                  setModal(null);
                  setNotice("Your listing is live in the marketplace.");
                })
              }
            >
              <label>
                Title
                <input name="title" maxLength="255" required />
              </label>
              <label>
                Description
                <textarea name="description" maxLength="255" required />
              </label>
              <div className="form-grid">
                <label>
                  Category
                  <select name="category">
                    {[
                      "Hardware",
                      "Software",
                      "Digital assets",
                      "Development",
                    ].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Listing type
                  <select name="kind">
                    {["SALE", "DIGITAL", "AUCTION", "SERVICE"].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Price / starting bid
                  <input
                    name="price"
                    type="number"
                    min="0.01"
                    max="9999999999.99"
                    step=".01"
                    required
                  />
                </label>
                <label>
                  Stock
                  <input
                    name="stock"
                    type="number"
                    min="1"
                    defaultValue="1"
                    required
                  />
                </label>
              </div>
              <label>
                Auction closes (required for auctions)
                <input name="endsAt" type="datetime-local" />
              </label>
              <button className="dark" disabled={busy}>
                Publish listing
              </button>
            </form>
          </>
        )}
        {modal.type === "topic" && (
          <>
            <h2>Start a conversation.</h2>
            <form
              onSubmit={(e) =>
                form(e, async (d) => {
                  await api("/topics", "POST", d);
                  await refresh();
                  setModal(null);
                })
              }
            >
              <label>
                Title
                <input name="title" maxLength="255" required />
              </label>
              <label>
                Your post
                <textarea name="body" maxLength="255" required />
              </label>
              <button className="dark" disabled={busy}>
                Post to community
              </button>
            </form>
          </>
        )}
        {modal.type === "thread" && (
          <>
            <span className="eyebrow">{modal.item.author}</span>
            <h2>{modal.item.title}</h2>
            <p>{modal.item.body}</p>
            {replies.map((r) => (
              <div className="reply" key={r.id}>
                <strong>{r.author}</strong>
                <p>{r.body}</p>
              </div>
            ))}
            {user ? (
              <form
                onSubmit={(e) =>
                  form(e, async (d) => {
                    await api(
                      "/topics/" + modal.item.id + "/replies",
                      "POST",
                      d,
                    );
                    setReplies(
                      await api("/topics/" + modal.item.id + "/replies"),
                    );
                    document.getElementById("reply-body").value = "";
                  })
                }
              >
                <label>
                  Your reply
                  <textarea
                    id="reply-body"
                    name="body"
                    maxLength="255"
                    required
                  />
                </label>
                <button className="dark" disabled={busy}>
                  Reply
                </button>
              </form>
            ) : (
              <button onClick={() => open({ type: "login" })}>
                Sign in to join the conversation ↗
              </button>
            )}
          </>
        )}
      </section>
    </div>
  );
}
