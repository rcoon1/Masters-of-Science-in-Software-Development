import MarketplaceDialog from "./components/MarketplaceDialog";
import Hero from "./components/Hero";
import Footer from "./components/Footer";
import React, { useEffect, useState } from "react";
import { api } from "./lib/api";
import { money } from "./lib/format";
export default function App() {
  const [page, setPage] = useState("Explore"),
    [items, setItems] = useState([]),
    [topics, setTopics] = useState([]),
    [user, setUser] = useState(null),
    [cart, setCart] = useState([]),
    [query, setQuery] = useState(""),
    [category, setCategory] = useState("All"),
    [modal, setModal] = useState(null),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [orders, setOrders] = useState([]),
    [bookings, setBookings] = useState([]),
    [replies, setReplies] = useState([]),
    [busy, setBusy] = useState(false);
  async function refresh() {
    const [i, t] = await Promise.all([api("/listings"), api("/topics")]);
    setItems(i);
    setTopics(t);
  }
  useEffect(() => {
    refresh().catch((e) =>
      setError("Cannot connect to the API. Start Docker Compose, then reload."),
    );
    api("/auth/me")
      .then(setUser)
      .catch(() => {});
  }, []);
  async function run(fn) {
    setBusy(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  function open(m) {
    setError("");
    setModal(m);
  }
  async function dashboard() {
    setPage("Dashboard");
    if (user)
      await run(async () => {
        const [o, b] = await Promise.all([api("/orders"), api("/bookings")]);
        setOrders(o);
        setBookings(b);
      });
  }
  const filtered = items.filter(
    (i) =>
      (page !== "Auctions" || i.kind === "AUCTION") &&
      (page !== "Services" || i.kind === "SERVICE") &&
      (category === "All" || i.category === category) &&
      (i.title + " " + i.description)
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  function form(event, fn) {
    event.preventDefault();
    const d = Object.fromEntries(new FormData(event.currentTarget));
    run(() => fn(d));
  }
  return (
    <>
      <header>
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setPage("Explore");
          }}
        >
          <span className="logo">b.</span>byte bazaar
          <span className="dot">®</span>
        </a>
        <nav>
          {["Explore", "Auctions", "Services", "Community"].map((x) => (
            <button
              className={page === x ? "active" : ""}
              onClick={() => {
                setPage(x);
                setCategory("All");
              }}
              key={x}
            >
              {x}
            </button>
          ))}
        </nav>
        <div className="actions">
          <button onClick={() => open({ type: "cart" })}>
            Bag <b>{cart.length}</b>
          </button>
          {user ? (
            <button onClick={dashboard}>{user.name.split(" ")[0]} ↗</button>
          ) : (
            <button onClick={() => open({ type: "login" })}>Sign in ↗</button>
          )}
          <button
            className="dark"
            onClick={() => open({ type: user ? "sell" : "login" })}
          >
            Start selling +
          </button>
        </div>
      </header>
      <main>
        {error && (
          <div role="alert" className="alert">
            {error}
            <button onClick={() => setError("")}>Dismiss</button>
          </div>
        )}
        {notice && (
          <div role="status" className="notice">
            {notice}
            <button onClick={() => setNotice("")}>Dismiss</button>
          </div>
        )}
        {page === "Explore" && <Hero />}
        {["Explore", "Auctions", "Services"].includes(page) && (
          <section id="catalog">
            <div className="section-top">
              <div>
                <span className="eyebrow">CURATED FOR YOUR NEXT MOVE</span>
                <h2>
                  {page === "Explore"
                    ? "Find something brilliant."
                    : page === "Auctions"
                      ? "Worth another bid."
                      : "Find your next collaborator."}
                </h2>
              </div>
              <label className="search">
                <span>⌕</span>
                <input
                  aria-label="Search marketplace"
                  placeholder="Search the bazaar…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </label>
            </div>
            <div className="filters">
              {[
                "All",
                "Hardware",
                "Software",
                "Digital assets",
                "Development",
              ].map((c) => (
                <button
                  className={category === c ? "selected" : ""}
                  onClick={() => setCategory(c)}
                  key={c}
                >
                  {c}
                </button>
              ))}
              <span>{filtered.length} discoveries</span>
            </div>
            <div className="grid">
              {filtered.map((i, index) => (
                <article className="card" key={i.id}>
                  <button
                    className={"product-art tone" + (index % 4)}
                    onClick={() => open({ type: "detail", item: i })}
                    aria-label={"View " + i.title}
                  >
                    <span className="tag">
                      {i.kind === "SALE" ? "HARDWARE" : i.kind}
                    </span>
                    <div className={"glyph " + i.kind.toLowerCase()}>
                      {i.kind === "SERVICE"
                        ? "↗"
                        : i.kind === "DIGITAL"
                          ? "</>"
                          : i.kind === "AUCTION"
                            ? "▣"
                            : "⌨"}
                    </div>
                    <span className="view">Explore ↗</span>
                  </button>
                  <div className="card-meta">
                    {i.category}
                    <span>{i.stock > 0 ? "Available" : "Sold out"}</span>
                  </div>
                  <button
                    className="title"
                    onClick={() => open({ type: "detail", item: i })}
                  >
                    {i.title}
                  </button>
                  <div className="price">
                    {money(i.price)}{" "}
                    <small>
                      {i.kind === "AUCTION"
                        ? "current bid"
                        : i.kind === "SERVICE"
                          ? "/ session"
                          : ""}
                    </small>
                    <button
                      aria-label={"View " + i.title}
                      onClick={() => open({ type: "detail", item: i })}
                    >
                      ↗
                    </button>
                  </div>
                </article>
              ))}
            </div>
            {!filtered.length && (
              <p className="empty">
                No listings found. Try a different search or category.
              </p>
            )}
          </section>
        )}
        {page === "Community" && (
          <section>
            <div className="section-top">
              <div>
                <span className="eyebrow">BETTER TOGETHER</span>
                <h1>The community corner.</h1>
                <p>Questions, discoveries, and the people behind the builds.</p>
              </div>
              <button
                className="dark"
                onClick={() => open({ type: user ? "topic" : "login" })}
              >
                Start a conversation +
              </button>
            </div>
            {topics.map((t) => (
              <button
                key={t.id}
                className="topic"
                onClick={() =>
                  run(async () => {
                    setReplies(await api("/topics/" + t.id + "/replies"));
                    open({ type: "thread", item: t });
                  })
                }
              >
                <span className="avatar">{t.author[0]}</span>
                <div>
                  <h3>{t.title}</h3>
                  <p>{t.body}</p>
                  <small>
                    {t.author} · {new Date(t.createdAt).toLocaleDateString()}
                  </small>
                </div>
                <span>↗</span>
              </button>
            ))}
          </section>
        )}
        {page === "Dashboard" && (
          <section>
            <span className="eyebrow">YOUR BYTE BAZAAR</span>
            <h1>Hello, {user?.name}.</h1>
            <button
              onClick={() =>
                run(async () => {
                  await api("/auth/logout", "POST");
                  setUser(null);
                  setPage("Explore");
                  setModal(null);
                })
              }
            >
              Sign out
            </button>
            <h2>Your orders</h2>
            {!orders.length && (
              <p>No orders yet. Your next discovery is waiting.</p>
            )}
            {orders.map((o) => (
              <div className="row" key={o.id}>
                <span>
                  #{o.id} · {o.title}
                </span>
                <strong>{money(o.total)}</strong>
                <small>{o.status}</small>
              </div>
            ))}
            <h2>Service requests</h2>
            {!bookings.length && <p>No service requests yet.</p>}
            {bookings.map((b) => (
              <div className="row" key={b.id}>
                <span>{items.find((i) => i.id === b.listingId)?.title}</span>
                <span>{b.scheduledDate}</span>
                <small>{b.status}</small>
              </div>
            ))}
            <h2>Your listings</h2>
            {items
              .filter((i) => i.sellerId === user?.id)
              .map((i) => (
                <div className="row" key={i.id}>
                  {i.title}
                  <span>
                    {money(i.price)} · {i.stock} in stock
                  </span>
                </div>
              ))}
          </section>
        )}
        <section className="banner">
          <div>
            <span className="eyebrow">HAVE SOMETHING WORTH SHARING?</span>
            <h2>Your next customer is here.</h2>
            <p>Turn your tech, talent, and ideas into new possibilities.</p>
          </div>
          <button onClick={() => open({ type: user ? "sell" : "login" })}>
            Open your storefront ↗
          </button>
        </section>
      </main>
      <Footer onExplore={() => setPage("Explore")} />
      {modal && (
        <MarketplaceDialog
          modal={modal}
          setModal={setModal}
          error={error}
          user={user}
          cart={cart}
          setCart={setCart}
          run={run}
          form={form}
          setUser={setUser}
          setNotice={setNotice}
          refresh={refresh}
          setReplies={setReplies}
          replies={replies}
          busy={busy}
          open={open}
        />
      )}
    </>
  );
}
