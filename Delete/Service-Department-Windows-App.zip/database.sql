create table if not exists public.work_orders (
  work_order_id text primary key,
  customer text not null,
  make text not null,
  model text not null,
  serial_number text not null,
  status text not null check (status in ('booked-in','in-progress','wop','waiting-on-approval','testing','done')),
  tech text not null,
  schedule_date date,
  pd text not null default '',
  updated_at timestamptz not null default now()
);

alter table public.work_orders enable row level security;

create policy "Authenticated users can read work orders"
on public.work_orders for select
to authenticated
using (true);

create policy "Authenticated users can add work orders"
on public.work_orders for insert
to authenticated
with check (true);

create policy "Authenticated users can update work orders"
on public.work_orders for update
to authenticated
using (true)
with check (true);

create policy "Authenticated users can delete work orders"
on public.work_orders for delete
to authenticated
using (true);
