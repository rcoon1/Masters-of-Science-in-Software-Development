(function () {
  const config = window.APP_CONFIG || {};
  const sessionKey = 'serviceDepartmentSession';

  function configured() {
    return config.SUPABASE_URL &&
      config.SUPABASE_ANON_KEY &&
      !config.SUPABASE_URL.includes('YOUR_PROJECT') &&
      !config.SUPABASE_ANON_KEY.includes('YOUR_SUPABASE');
  }

  function getStoredSession() {
    try { return JSON.parse(localStorage.getItem(sessionKey)); }
    catch { return null; }
  }

  function storeSession(session) {
    if (session) localStorage.setItem(sessionKey, JSON.stringify(session));
    else localStorage.removeItem(sessionKey);
  }

  async function request(path, options = {}, useAuth = true) {
    if (!configured()) {
      throw new Error('Supabase is not configured. Add the project URL and public anon key to config.js.');
    }

    const session = getStoredSession();
    const headers = {
      apikey: config.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };
    if (useAuth && session?.access_token) headers.Authorization = `Bearer ${session.access_token}`;

    const response = await fetch(`${config.SUPABASE_URL}${path}`, { ...options, headers });
    const text = await response.text();
    const data = text ? JSON.parse(text) : null;
    if (!response.ok) throw new Error(data?.msg || data?.message || data?.error_description || `Request failed (${response.status})`);
    return data;
  }

  async function signIn(email, password) {
    const session = await request('/auth/v1/token?grant_type=password', {
      method: 'POST', body: JSON.stringify({ email, password })
    }, false);
    storeSession(session);
    return session;
  }

  async function signUp(email, password) {
    const result = await request('/auth/v1/signup', {
      method: 'POST', body: JSON.stringify({ email, password })
    }, false);
    if (result.access_token) storeSession(result);
    return { ...result, session: result.access_token ? result : null };
  }

  async function getSession() {
    const session = getStoredSession();
    if (!session?.access_token) return null;
    try {
      const user = await request('/auth/v1/user');
      return { ...session, user };
    } catch {
      if (!session.refresh_token) return null;
      try {
        const refreshed = await request('/auth/v1/token?grant_type=refresh_token', {
          method: 'POST', body: JSON.stringify({ refresh_token: session.refresh_token })
        }, false);
        storeSession(refreshed);
        return refreshed;
      } catch {
        storeSession(null);
        return null;
      }
    }
  }

  function toDatabase(order) {
    return {
      work_order_id: String(order.workOrderId),
      customer: order.customer,
      make: order.make,
      model: order.model,
      serial_number: order.serialNumber,
      status: order.status,
      tech: order.tech,
      schedule_date: order.scheduleDate || null,
      pd: order.pd || ''
    };
  }

  function fromDatabase(order) {
    return {
      workOrderId: order.work_order_id,
      customer: order.customer,
      make: order.make,
      model: order.model,
      serialNumber: order.serial_number,
      status: order.status,
      tech: order.tech,
      scheduleDate: order.schedule_date || '',
      pd: order.pd || ''
    };
  }

  async function loadAll() {
    const rows = await request('/rest/v1/work_orders?select=*&order=schedule_date.asc.nullslast,work_order_id.asc');
    return rows.map(fromDatabase);
  }

  async function saveAll(orders) {
    if (orders.length) {
      await request('/rest/v1/work_orders?on_conflict=work_order_id', {
        method: 'POST',
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
        body: JSON.stringify(orders.map(toDatabase))
      });
    }
  }

  async function deleteOne(workOrderId) {
    await request(`/rest/v1/work_orders?work_order_id=eq.${encodeURIComponent(workOrderId)}`, {
      method: 'DELETE', headers: { Prefer: 'return=minimal' }
    });
  }

  async function signOut() {
    try { await request('/auth/v1/logout', { method: 'POST' }); }
    finally { storeSession(null); }
  }

  window.serviceApi = { signIn, signUp, signOut, getSession, loadAll, saveAll, deleteOne };
})();
