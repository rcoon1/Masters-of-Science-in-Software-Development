# Service Department Desktop

Windows desktop work-order application with authenticated, shared cloud data.

## 1. Configure Supabase

1. Create a Supabase project.
2. Open the SQL Editor and run `database.sql`.
3. Open Project Settings > API.
4. Copy the Project URL and public anon key into `config.js`.
5. In Authentication settings, enable Email authentication. Choose whether new users must confirm their email.

This package assumes one private organization: every authenticated account can access the same work orders. Only invite trusted staff to create accounts.

## 2. Run the application

Install Node.js LTS on Windows, open PowerShell in this folder, then run:

```powershell
npm install
npm start
```

## 3. Create a Windows installer

```powershell
npm run build:windows
```

The installer will be created in the `dist` folder.

## Included features

- Email/password user accounts
- Shared work orders across computers
- Add, update, delete, search, and date filtering
- Monthly schedule calendar
- Daily technician-column view
- Work-order lists by selected status
- KPI dashboard

## Security note

Use only the public Supabase anon key in `config.js`. Never place the Supabase service-role key in this desktop application.
