export type Category = 'Travel' | 'Energy' | 'Water' | 'Waste' | 'Purchase';
export type Activity = { id: string; category: Category; type: string; amount: number; unit: string; date: string; note: string; co2: number | null; factor: number | null };
export type Post = { id: string; text: string; date: string };
export type State = { version: 1; onboarded: boolean; name: string; focus: Category; activities: Activity[]; posts: Post[]; joined: boolean; goal: number; visibility: 'Private' | 'Friends'; savedLessons: string[]; factors: { car: number; bus: number; train: number; electricity: number }; };
export const initialState: State = { version: 1, onboarded: false, name: '', focus: 'Travel', activities: [], posts: [], joined: false, goal: 5, visibility: 'Private', savedLessons: [], factors: { car: 0.17, bus: 0.1, train: 0.04, electricity: 0.4 } };
export const categories: Category[] = ['Travel', 'Energy', 'Water', 'Waste', 'Purchase'];
export const types: Record<Category, string[]> = { Travel: ['Walk', 'Bike', 'Car', 'Bus', 'Train'], Energy: ['Electricity'], Water: ['Water use'], Waste: ['Recycling', 'Compost', 'Landfill'], Purchase: ['Food', 'Household', 'Other'] };
export const units: Record<Category, string> = { Travel: 'km', Energy: 'kWh', Water: 'L', Waste: 'kg', Purchase: 'items' };
export function dayKey(d = new Date()): string { return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
export function validDay(value: string): boolean { if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false; const date = new Date(`${value}T12:00:00`); return !Number.isNaN(+date) && dayKey(date) === value; }
export function recentDays(now = new Date(), count = 7): string[] { return Array.from({length:count},(_,i)=>{const d=new Date(now);d.setDate(d.getDate()-count+1+i);return dayKey(d);}); }
export function estimate(category: Category, type: string, amount: number, factors: State['factors'], custom?: number): { co2: number | null; factor: number | null } {
 let factor: number | null = null;
 if (category === 'Travel') factor = ({Walk:0,Bike:0,Car:factors.car,Bus:factors.bus,Train:factors.train} as Record<string,number>)[type] ?? null;
 if (category === 'Energy') factor = factors.electricity;
 if (category === 'Purchase' && custom !== undefined) factor = custom;
 return { co2: factor === null ? null : Math.round(amount * factor * 1000)/1000, factor };
}
export function makeActivity(category: Category, type: string, input: string, date: string, note: string, factors: State['factors'], customInput = ''): Activity {
 const amount = Number(input.trim()); const custom = customInput.trim() === '' ? undefined : Number(customInput);
 if (!input.trim() || !Number.isFinite(amount) || amount <= 0 || amount > 1000000) throw new Error('Enter an amount greater than zero and no more than 1,000,000.');
 if (category === 'Purchase' && !Number.isInteger(amount)) throw new Error('Enter a whole number of items.');
 if (!types[category]?.includes(type)) throw new Error('Choose a valid activity type.');
 if (!validDay(date) || date > dayKey()) throw new Error('Use a valid date (YYYY-MM-DD), today or earlier.');
 if (custom !== undefined && (!Number.isFinite(custom) || custom < 0 || custom > 1000000)) throw new Error('Product impact must be zero or a positive number.');
 return { id: `${Date.now()}-${Math.random().toString(36).slice(2,10)}`, category, type, amount, unit: units[category], date, note: note.trim().slice(0,300), ...estimate(category,type,amount,factors,custom) };
}
export function summary(activities: Activity[], days: string[]) {
 const selected = activities.filter(a=>days.includes(a.date));
 return { activities:selected, co2: selected.reduce((sum,a)=>sum+(a.co2??0),0), estimated:selected.filter(a=>a.co2!==null).length, unknown:selected.filter(a=>a.co2===null).length, water:selected.filter(a=>a.category==='Water').reduce((s,a)=>s+a.amount,0), waste:selected.filter(a=>a.category==='Waste').reduce((s,a)=>s+a.amount,0), energy:selected.filter(a=>a.category==='Energy').reduce((s,a)=>s+a.amount,0), greenTrips:selected.filter(a=>a.category==='Travel' && ['Walk','Bike','Bus','Train'].includes(a.type)).length };
}
export function streak(activities: Activity[], now = new Date()): number {
 const days=new Set(activities.map(a=>a.date)); const d=new Date(now);
 if (!days.has(dayKey(d))) d.setDate(d.getDate()-1);
 let n=0; while(days.has(dayKey(d))) { n++;d.setDate(d.getDate()-1); } return n;
}
export function points(activities: Activity[]): number { return new Set(activities.map(a=>a.date)).size*10; }
export function restore(raw: string): State {
 const v=JSON.parse(raw) as State;
 if (v.version!==1 || !Array.isArray(v.activities) || !Array.isArray(v.posts) || typeof v.name!=='string' || typeof v.onboarded!=='boolean' || !categories.includes(v.focus) || typeof v.joined!=='boolean' || !Number.isInteger(v.goal) || v.goal<1 || v.goal>50 || !['Private','Friends'].includes(v.visibility) || !Array.isArray(v.savedLessons) || !v.savedLessons.every(x=>typeof x==='string')) throw new Error('Saved data has an unsupported format.');
 for (const k of ['car','bus','train','electricity'] as const) if (!Number.isFinite(v.factors?.[k]) || v.factors[k]<0 || v.factors[k]>100) throw new Error('Saved impact factors are invalid.');
 if (!v.activities.every(a=>typeof a.id==='string' && categories.includes(a.category) && types[a.category].includes(a.type) && Number.isFinite(a.amount) && a.amount>0 && a.amount<=1000000 && validDay(a.date) && typeof a.note==='string' && a.unit===units[a.category] && (a.co2===null || (Number.isFinite(a.co2)&&a.co2>=0)) && (a.factor===null || (Number.isFinite(a.factor)&&a.factor>=0)))) throw new Error('Saved activities could not be read.');
 if (!v.posts.every(p=>typeof p.id==='string' && typeof p.text==='string' && typeof p.date==='string')) throw new Error('Saved posts could not be read.');
 return v;
}
