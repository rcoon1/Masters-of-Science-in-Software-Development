import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, makeActivity, estimate, summary, dayKey, recentDays, streak, points, restore, validDay } from '../src/model.ts';
const factors=initialState.factors;
const a=(date,type='Bike')=>({...makeActivity('Travel',type,'5',dayKey(),' ',factors),date});
test('calendar calculations cross month boundaries using local dates',()=>{
 assert.deepEqual(recentDays(new Date(2026,2,2),3),['2026-02-28','2026-03-01','2026-03-02']);
 assert.equal(validDay('2026-02-30'),false);assert.equal(validDay('2024-02-29'),true);
});
test('invalid entries and future dates never become logs',()=>{
 for(const amount of ['', '0','-1','Infinity','abc','1000001'])assert.throws(()=>makeActivity('Travel','Car',amount,dayKey(),'',factors));
 assert.throws(()=>makeActivity('Travel','Car','2','2999-01-01','',factors));
 assert.throws(()=>makeActivity('Purchase','Food','1.5',dayKey(),'',factors));
 assert.throws(()=>makeActivity('Purchase','Food','1',dayKey(),'',factors,'-2'));
});
test('unknown lifecycle impact remains unknown, zero travel remains zero',()=>{
 assert.equal(estimate('Water','Water use',20,factors).co2,null);
 assert.equal(estimate('Purchase','Food',1,factors).co2,null);
 assert.equal(estimate('Travel','Bike',5,factors).co2,0);
 assert.equal(estimate('Purchase','Food',2,factors,1.2).co2,2.4);
});
test('period totals exclude old logs and preserve independent resource metrics',()=>{
 const date=dayKey();const logs=[a(date,'Car'),a('2020-01-01','Car'),makeActivity('Water','Water use','20',date,'',factors)];
 const s=summary(logs,[date]);assert.equal(s.co2,.85);assert.equal(s.water,20);assert.equal(s.estimated,1);assert.equal(s.unknown,1);
});
test('streak allows unfinished today, points cannot grow with duplicate daily logs',()=>{
 const logs=[a('2026-03-01'),a('2026-02-28'),a('2026-02-28')];
 assert.equal(streak(logs,new Date(2026,2,2)),2);assert.equal(points(logs),20);
 assert.equal(streak(logs,new Date(2026,2,4)),0);
});
test('backup round trip and malformed data rejection',()=>{
 const state={...initialState,activities:[a(dayKey())]};assert.deepEqual(restore(JSON.stringify(state)),state);
 assert.throws(()=>restore('{'));assert.throws(()=>restore(JSON.stringify({...state,version:9})));
 assert.throws(()=>restore(JSON.stringify({...state,activities:[{...state.activities[0],amount:-1}]})));
});
test('recorded estimates remain stable after factor edits',()=>{
 const log=makeActivity('Energy','Electricity','10',dayKey(),'',factors);
 const changed={...factors,electricity:.2};assert.equal(log.co2,4);assert.equal(log.factor,.4);
 assert.equal(estimate('Energy','Electricity',10,changed).co2,2);
});
