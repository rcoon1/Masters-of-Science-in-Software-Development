# EcoTrack — iPhone and Android starter app

A working Expo / React Native app based on the EcoTrack wireframes. The app runs offline and starts with an empty activity history. It is a local-first MVP, not an App Store release or a live social platform.

## Run it on your phone

1. Install Node.js 24 LTS (or a compatible supported Node release) on your computer.
2. Unzip this package and open a terminal inside the `EcoTrack` folder.
3. Run:

   ```sh
   npm ci
   npm start
   ```

4. Install **Expo Go** on your iPhone or Android phone. Use a version supporting this project's Expo SDK 57. See https://expo.dev/go for compatibility.
5. Keep the computer and phone on the same Wi-Fi. Scan the terminal QR code using the iPhone Camera or the Android Expo Go scanner.
6. Enter a nickname, choose a focus, and log your first activity.

If the local network blocks connections, try `npx expo start --tunnel`. That option requires internet and may prompt to install Expo's tunnel helper. The terminal's preview URL exists only while the development server is running. This ZIP itself is not a phone-installable binary.

Optional computer preview: `npm run web`. Native camera scanning and reminders should be checked on a physical phone. The web preview uses manual barcode input and does not schedule reminders.

## What works

- Onboarding and editable local profile.
- Manual travel, electricity, water, waste, and purchase logging with amount/date validation.
- Activity history, filtering, deletion confirmation, and persistent device storage.
- Today and rolling 7/30-day summaries, 7-day chart, category breakdowns and resource totals.
- Adjustable weekly greener-trip goal, logging streaks and personal points/badges.
- Illustrative per-km and per-kWh impact factors, editable in Profile. Entries retain their original factor.
- Camera barcode capture with an optional permission request, plus manual entry fallback. A captured barcode is attached to the purchase note.
- Optional local daily notification with chosen time; disable/update controls. No push token is requested.
- Educational tips with saved-reading state.
- Clearly labeled sample community posts, local drafts, a personal challenge preview, and the native share sheet.
- Data export through the share sheet and confirmed deletion of local data/reminders.
- Load failure protection: unreadable data is not automatically overwritten; raw backup export is offered.

## What needs connected services before a public launch

| Feature | Current state | Needed for launch |
| --- | --- | --- |
| Accounts and cross-device sync | None; local profile | Authentication, database, account deletion and sync |
| Smart-home and utility imports | Explicitly not connected | Provider contracts/APIs, authorization and deduplication |
| GPS trip detection | No location permission or tracking | Consent-based location integration, mode detection and trip review |
| Product lifecycle lookup | Barcode capture + manual fields | Licensed product/impact database and source metadata |
| Community, groups and rankings | Sample feed + local drafts | Backend, audience enforcement, moderation and reporting |
| Merchant rewards and donations | Personal points/badges only | Partner agreements, redemption service and audit records |
| News feed | Original static educational tips | Curated live feed and publisher attribution |
| Encryption | Standard local AsyncStorage | Assess encrypted storage, transport, backend security and backup policy |

No authentication, encrypted-cloud-storage, real-time measurement, verified emissions, live social posting, donation or coupon redemption is claimed by this build. The privacy screen states these limits. The audience preference is stored for future use and does not publish anything.

## Estimation rules

Initial factors are **illustrative assumptions**, not researched or certified factors: car 0.17, bus 0.10, train 0.04 kg CO2e/km; electricity 0.40 kg CO2e/kWh. Enter appropriate published or supplier factors before relying on the totals. Walking/biking show zero **direct** travel emissions. The simple model excludes indirect lifecycle impacts.

Water (L) and waste (kg) keep their own resource units and do not get a carbon estimate. Purchases remain unknown unless the user supplies impact per item. Unknowns are excluded from carbon sums and are counted separately. Days without logs show zero *logged* impact. The app does not claim to capture a full footprint or calculate savings against an unmeasured baseline.

Travel uses kilometers. Log each trip once. The greener-trip goal counts Walk, Bike, Bus and Train activity records in the last 7 local calendar days. Points award 10 per distinct day with an entry; duplicate entries on a day do not add points. The logging streak tolerates an unfinished current day.

## Build a standalone app

The package includes `eas.json`. To generate installable binaries, use your own Expo account and Apple/Google developer credentials:

```sh
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest build --platform android --profile preview
```

The preview profile produces an Android APK. For an internal iPhone build, register test devices and run `npx eas-cli@latest build --platform ios --profile preview`; iOS signing requires your Apple developer account. Production builds use the `production` profile. Store submission and screenshots are separate steps.

Before production, confirm a unique app identifier you own. The scaffold uses `com.ryancoon.ecotrack` for both platforms; adjust `app.json` if needed. Let EAS configure its project identifier for your own account. No developer account, hosting service, build quota or paid service has been created or used here.

## Development and validation

```sh
npm run typecheck
npm test
npx expo install --check
npm run export
```

- `App.tsx`: navigation, screen components, modals and device actions.
- `src/model.ts`: data model, input validation, dates, estimates, summaries and restore validation.
- `tests/model.test.mjs`: calculation, calendar, validation and persistence-format tests.
- `app.json`: native identifiers, icons and camera/notification plugins.
- `eas.json`: preview and production build profiles.
- `preview/`: screenshots from the responsive web rendition, where available.

Type checking, dependency compatibility, and iOS/Android JavaScript bundles were verified in the build environment. This does not replace physical-device testing, signed native builds, permission testing, or app-store review. See `VALIDATION.md` for the exact checks completed.

## Relevant official documentation

- Project setup: https://docs.expo.dev/get-started/create-a-project/
- SDK 57 camera: https://docs.expo.dev/versions/v57.0.0/sdk/camera/
- SDK 57 notifications: https://docs.expo.dev/versions/v57.0.0/sdk/notifications/
- EAS builds: https://docs.expo.dev/build/introduction/
