# Spring JDBC verification

- Compiled all backend Java sources for Java 17 against the Spring Boot-managed dependency versions using the Eclipse Java compiler.
- Exercised the JDBC repository on H2 in MySQL compatibility mode: generated IDs, bid and winner persistence, moderation, and transaction rollback passed. The temporary H2 setup split multi-clause ALTER statements and substituted the seed timestamp function; the shipped MySQL migrations are unchanged.
- React production build passed. The Python smoke script parsed successfully.
- Full Maven packaging and live Spring Boot/MySQL end-to-end testing were not completed in this environment.

To verify against MySQL, start the VS Code tasks described in the README. Run `py tests/smoke.py --admin` on Windows or `python3 tests/smoke.py --admin` elsewhere. This checks checkout rollback as well as the public and admin flows, and creates development test data.
