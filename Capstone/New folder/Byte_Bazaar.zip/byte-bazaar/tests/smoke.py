"""Integration checks against a running local frontend and API; Python standard library only."""
import json, urllib.request, urllib.error, http.cookiejar, uuid, datetime
base="http://localhost:5173/api"
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
token=None
def call(path, method="GET", body=None, status=200, csrf=True):
    headers={"Content-Type":"application/json"}
    if method!="GET" and csrf: headers["X-XSRF-TOKEN"]=token
    req=urllib.request.Request(base+path, data=json.dumps(body).encode() if body is not None else None, method=method, headers=headers)
    try:
        with client.open(req) as res: code=res.status; raw=res.read()
    except urllib.error.HTTPError as e: code=e.code; raw=e.read()
    assert code==status, (path,code,raw.decode())
    return json.loads(raw) if raw else None
token=call("/csrf")["token"]
call("/auth/register","POST",{},status=403,csrf=False)
suffix=uuid.uuid4().hex[:12]
creds={"email":suffix+"@example.com","password":"test-strong-password","name":"Smoke test"}
me=call("/auth/register","POST",creds)
assert "password" not in me
assert call("/auth/me")["id"]==me["id"]
listing=call("/listings","POST",{"title":"Smoke item","description":"Integration check","category":"Hardware","kind":"SALE","price":12.50,"stock":1})
call("/auth/logout","POST")
token=call("/csrf")["token"]
creds2={**creds,"email":"buyer-"+creds["email"]}
call("/auth/register","POST",creds2)
order=call("/orders","POST",{"listingIds":[listing["id"]]})
assert order[0]["total"]==12.5
call("/orders","POST",{"listingIds":[listing["id"]]},status=400)
assert len(call("/orders"))==1
# The valid row sorts before the sold-out row to exercise rollback after a write.
# Create that ordering using two new listings.
call("/auth/login", "POST", creds)
valid = call("/listings", "POST", {"title":"Rollback first","description":"Integration check","category":"Hardware","kind":"SALE","price":8,"stock":1})
blocked = call("/listings", "POST", {"title":"Rollback second","description":"Integration check","category":"Hardware","kind":"SALE","price":8,"stock":1})
call("/auth/login", "POST", creds2)
call("/orders", "POST", {"listingIds":[blocked["id"]]})
call("/orders", "POST", {"listingIds":[valid["id"], blocked["id"]]}, status=400)
assert next(row for row in call("/listings") if row["id"] == valid["id"])["stock"] == 1
assert not any(row["listingId"] == valid["id"] for row in call("/orders"))
items=call("/listings")
auction=next(i for i in items if i["kind"]=="AUCTION")
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":float(auction["price"])+1})
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":auction["price"]},status=400)
service=next(i for i in items if i["kind"]=="SERVICE")
call("/bookings","POST",{"listingId":service["id"],"scheduledDate":str(datetime.date.today()+datetime.timedelta(days=3)),"notes":"Smoke request"})
assert call("/bookings")
topic=call("/topics","POST",{"title":"Smoke "+suffix,"body":"Forum integration check"})
call("/topics/"+str(topic["id"])+"/replies","POST",{"body":"Reply check"})
assert len(call("/topics/"+str(topic["id"])+"/replies"))==1
print("PASS: registration, CSRF, sessions, checkout, stock, bids, bookings, forum")

# Optional admin lifecycle checks against the same development database.
if "--admin" in __import__("sys").argv:
    from getpass import getpass

    call("/admin/overview", status=403)
    call("/admin/login", "POST", creds2, status=401)
    admin_credentials = {"email": input("Admin email: "), "password": getpass("Admin password: ")}
    assert call("/admin/login", "POST", admin_credentials)["admin"]
    item = {"title": "Admin smoke " + suffix, "description": "Development test",
            "kind": "SALE", "category": "Hardware", "price": 20, "stock": 1}
    listing = call("/admin/listings", "POST", item)
    call(f"/admin/listings/{listing['id']}/visibility", "POST", {"hidden": True})
    assert not any(x["id"] == listing["id"] for x in call("/listings"))

    draft = call("/admin/listings", "POST", {**item, "kind": "AUCTION",
        "endsAt": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=1)).isoformat()})
    aid = draft["id"]
    assert draft["auctionStatus"] == "DRAFT"
    assert not any(x["id"] == aid for x in call("/listings"))
    assert call(f"/admin/auctions/{aid}/start", "POST")["auctionStatus"] == "OPEN"
    call("/auth/login", "POST", creds2)
    placed = call(f"/listings/{aid}/bids", "POST", {"amount": 21})
    call("/admin/login", "POST", admin_credentials)
    closed = call(f"/admin/auctions/{aid}/close", "POST")
    assert closed["winningBidId"] == placed["id"]
    call("/auth/login", "POST", creds2)
    call(f"/listings/{aid}/bids", "POST", {"amount": 22}, status=400)

    call("/admin/login", "POST", admin_credentials)
    tid = topic["id"]
    reply = call(f"/topics/{tid}/replies")[0]
    call(f"/admin/replies/{reply['id']}/visibility", "POST", {"hidden": True})
    assert call(f"/topics/{tid}/replies") == []
    call(f"/admin/topics/{tid}/visibility", "POST", {"hidden": True})
    call(f"/topics/{tid}/replies", status=404)
    call(f"/admin/topics/{tid}/visibility", "POST", {"hidden": False})
    assert call(f"/topics/{tid}/replies") == []
    print("PASS: admin permissions, storefront removal, auction lifecycle, forum moderation")
