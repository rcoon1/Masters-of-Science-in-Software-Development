package com.bytebazaar;

public class Topic {

  public Long id;

  public boolean hidden;

  public Long authorId;
  public String author;
  public String title;
  public String body;
  public java.time.Instant createdAt;
}
