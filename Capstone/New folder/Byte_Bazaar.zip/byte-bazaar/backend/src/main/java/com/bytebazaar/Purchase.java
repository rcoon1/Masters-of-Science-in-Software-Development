package com.bytebazaar;

public class Purchase {

  public Long id;

  public Long buyerId;
  public Long listingId;
  public String title;

  public java.math.BigDecimal total;

  public String status;
  public java.time.Instant createdAt;
}
