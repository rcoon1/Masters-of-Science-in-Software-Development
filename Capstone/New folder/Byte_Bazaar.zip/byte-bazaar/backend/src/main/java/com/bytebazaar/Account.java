package com.bytebazaar;

public class Account {

  public Long id;

  public boolean admin;

  public String name;
  public String email;

  @com.fasterxml.jackson.annotation.JsonIgnore
  public String password;
}
