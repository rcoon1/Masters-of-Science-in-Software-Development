"""Integration checks against a running local frontend and API; Python standard library only."""
import json, urllib.request, urllib.error, http.cookiejar, uuid, datetime
base="http://localhost:5173/api"
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
token=None
def call(path, method="GET", body=None, status=200, csrf=True):
    headers={"Content-Type":"application/json"}
    if method!="GET" and csrf: headers["X-XSRF-TOKEN"]=token
    if path == "/orders" and method == "POST" and body and "listingIds" in body:
        body = {"recipientName":"Smoke Test","email":"buyer@example.com","phone":"5551234567","shippingAddress":"100 Main St, Austin, TX 78701, US","billingAddress":"100 Main St, Austin, TX 78701, US","shippingMethod":"STANDARD",**body}
    req=urllib.request.Request(base+path, data=json.dumps(body).encode() if body is not None else None, method=method, headers=headers)
    try:
        with client.open(req) as res: code=res.status; raw=res.read()
    except urllib.error.HTTPError as e: code=e.code; raw=e.read()
    assert code==status, (path,code,raw.decode())
    return json.loads(raw) if raw else None
def image_upload(path, field, status=200):
    import base64
    boundary="ByteBazaar"+uuid.uuid4().hex
    image=base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=")
    payload=(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; filename=\"pixel.png\"\r\nContent-Type: image/png\r\n\r\n").encode()+image+f"\r\n--{boundary}--\r\n".encode()
    req=urllib.request.Request(base+path,data=payload,method="POST",headers={"Content-Type":"multipart/form-data; boundary="+boundary,"X-XSRF-TOKEN":token})
    try:
        with client.open(req) as response: code=response.status; raw=response.read()
    except urllib.error.HTTPError as error: code=error.code; raw=error.read()
    assert code==status,(path,code,raw.decode())
    return json.loads(raw) if raw else None

token=call("/csrf")["token"]
call("/auth/register","POST",{},status=403,csrf=False)
suffix=uuid.uuid4().hex[:12]
creds={"email":suffix+"@example.com","password":"test-strong-password","username":"smoke_"+suffix,"firstName":"Smoke","lastName":"Test","phone":"5551234567","shippingAddress":"100 Main St, Austin, TX 78701, United States"}
me=call("/auth/register","POST",creds)
assert "password" not in me
assert me["username"]==creds["username"]
call("/auth/register","POST",{**creds,"email":"duplicate-"+creds["email"],"username":creds["username"].upper()},status=400)
assert call("/auth/me")["id"]==me["id"]
listing=call("/listings","POST",{"title":"Smoke item","description":"Integration check","category":"PC Components","subcategory":"Other Components","kind":"SALE","price":12.50,"stock":1})
call("/auth/logout","POST")
token=call("/csrf")["token"]
creds2={**creds,"email":"buyer-"+creds["email"],"username":"buyer_"+suffix}
call("/auth/register","POST",creds2)
order=call("/orders","POST",{"listingIds":[listing["id"]]})
assert order[0]["total"]==20.49
assert order[0]["shippingCost"]==7.99
assert order[0]["recipientName"]=="Smoke Test"
assert order[0]["checkoutId"]
assert call("/orders")[0]["shippingAddress"]==order[0]["shippingAddress"]
call("/orders","POST",{"listingIds":[listing["id"]]},status=400)
assert len(call("/orders"))==1
# The valid row sorts before the sold-out row to exercise rollback after a write.
# Create that ordering using two new listings.
call("/auth/login", "POST", creds)
valid = call("/listings", "POST", {"title":"Rollback first","description":"Integration check","category":"PC Components","subcategory":"Other Components","kind":"SALE","price":8,"stock":1})
blocked = call("/listings", "POST", {"title":"Rollback second","description":"Integration check","category":"PC Components","subcategory":"Other Components","kind":"SALE","price":8,"stock":1})
call("/auth/login", "POST", creds2)
call("/orders", "POST", {"listingIds":[blocked["id"]]})
call("/orders", "POST", {"listingIds":[valid["id"], blocked["id"]]}, status=400)
assert next(row for row in call("/listings") if row["id"] == valid["id"])["stock"] == 1
assert not any(row["listingId"] == valid["id"] for row in call("/orders"))
items=call("/listings")
auction=next(i for i in items if i["kind"]=="AUCTION")
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":float(auction["price"])+1})
call("/listings/"+str(auction["id"])+"/bids","POST",{"amount":auction["price"]},status=400)
service=next(i for i in items if i["kind"]=="SERVICE")
call("/bookings","POST",{"listingId":service["id"],"scheduledDate":str(datetime.date.today()+datetime.timedelta(days=3)),"notes":"Smoke request"})
assert call("/bookings")
topic=call("/topics","POST",{"title":"Smoke "+suffix,"body":"Forum integration check","category":"Community Hub","subcategory":"General Discussion"})
call("/topics/"+str(topic["id"])+"/replies","POST",{"body":"Reply check"})
assert len(call("/topics/"+str(topic["id"])+"/replies"))==1
listed_topic=next(t for t in call("/topics") if t["id"]==topic["id"])
assert listed_topic["subcategory"]=="General Discussion"
assert listed_topic["replyCount"]==1
assert listed_topic["author"]==creds2["username"]
updated=call("/profile","PUT",{"username":"renamed_"+suffix})
assert updated["username"]=="renamed_"+suffix
assert next(t for t in call("/topics") if t["id"]==topic["id"])["author"]==updated["username"]
assert call("/topics/"+str(topic["id"])+"/replies")[0]["author"]==updated["username"]
image_upload("/profile/avatar","file")
assert call("/auth/me")["avatarVersion"]>0
image_upload("/topics/"+str(topic["id"])+"/photos","files")
photos=call("/topics/"+str(topic["id"])+"/photos")
assert len(photos)==1
reply_id=call("/topics/"+str(topic["id"])+"/replies")[0]["id"]
image_upload(f"/topics/{topic['id']}/replies/{reply_id}/photos","files")
assert len(call(f"/topics/{topic['id']}/replies/{reply_id}/photos"))==1
call("/auth/login","POST",creds)
image_upload("/topics/"+str(topic["id"])+"/photos","files",status=403)
call("/auth/login","POST",creds2)
call(f"/topics/{topic['id']}/photos/{photos[0]}","DELETE")
assert call("/topics/"+str(topic["id"])+"/photos")==[]
assert call("/profile/avatar","DELETE")["avatarVersion"]==0

call("/topics","POST",{"title":"Wrong board","body":"Rejected","category":"Community Hub","subcategory":"Build Planning"},status=400)
call("/listings","POST",{"title":"Wrong shelf","description":"Rejected","category":"Storage","subcategory":"Graphics Cards","kind":"SALE","price":10,"stock":1},status=400)
print("PASS: registration, CSRF, sessions, checkout, stock, bids, bookings, forum")

# Optional admin lifecycle checks against the same development database.
if "--admin" in __import__("sys").argv:
    from getpass import getpass

    call("/admin/overview", status=403)
    call("/admin/login", "POST", creds2, status=401)
    admin_credentials = {"email": input("Admin email: "), "password": getpass("Admin password: ")}
    assert call("/admin/login", "POST", admin_credentials)["admin"]
    item = {"title": "Admin smoke " + suffix, "description": "Development test",
            "kind": "SALE", "category": "PC Components", "subcategory": "Other Components", "price": 20, "stock": 1}
    listing = call("/admin/listings", "POST", item)
    call(f"/admin/listings/{listing['id']}/visibility", "POST", {"hidden": True})
    assert not any(x["id"] == listing["id"] for x in call("/listings"))

    draft = call("/admin/listings", "POST", {**item, "kind": "AUCTION",
        "endsAt": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=1)).isoformat()})
    aid = draft["id"]
    assert draft["auctionStatus"] == "DRAFT"
    assert not any(x["id"] == aid for x in call("/listings"))
    assert call(f"/admin/auctions/{aid}/start", "POST")["auctionStatus"] == "OPEN"
    call("/auth/login", "POST", creds2)
    placed = call(f"/listings/{aid}/bids", "POST", {"amount": 21})
    call("/admin/login", "POST", admin_credentials)
    closed = call(f"/admin/auctions/{aid}/close", "POST")
    assert closed["winningBidId"] == placed["id"]
    call("/auth/login", "POST", creds2)
    call(f"/listings/{aid}/bids", "POST", {"amount": 22}, status=400)

    call("/admin/login", "POST", admin_credentials)
    tid = topic["id"]
    reply = call(f"/topics/{tid}/replies")[0]
    call(f"/admin/replies/{reply['id']}/visibility", "POST", {"hidden": True})
    assert call(f"/topics/{tid}/replies") == []
    call(f"/admin/topics/{tid}/visibility", "POST", {"hidden": True})
    call(f"/topics/{tid}/replies", status=404)
    call(f"/admin/topics/{tid}/visibility", "POST", {"hidden": False})
    assert call(f"/topics/{tid}/replies") == []
    print("PASS: admin permissions, storefront removal, auction lifecycle, forum moderation")
