# Latest update verification

Passed: frontend production build, formatting and DOM integration with mocked APIs for the storefront/category/checkout/forum flows plus required signup username, signup avatar, username editing, avatar display/removal/replacement, topic/reply attachments, file-picker validation and author-only media controls.

Backend sources were parsed/formatted with the Java Prettier parser. Java compilation, JUnit and live MySQL integration were not run because Maven/JDK compilation tools are unavailable. Browser visual verification remains untested here.

Run `npm ci`, `npm test`, `npm run build`, `npm run format:check` in frontend. Run `mvn test` in backend, then `python tests/smoke.py` with the full application running. Flyway V6 adds usernames, avatar storage and forum-photo storage. New backend checks are in ProfilePhotoTest; existing TaxonomyTest now verifies identity joins.

## Port-conflict update

Passed: `node scripts/start.test.mjs` checks occupied-port fallback, explicit Spring port arguments, matching Vite environment, Windows child-process settings/cleanup, and missing-dependency/bind-error handling using mocked OS/process calls. `node --check scripts/start.mjs`, frontend formatting and the frontend production build passed. Live Windows startup and backend execution are not verified in this environment.

Default/manual backend port is now 18080. The Windows launcher selects free ports and configures both backend and frontend for the chosen values, overriding older port settings.
