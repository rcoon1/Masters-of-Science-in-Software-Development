# Byte Bazaar — VS Code edition

React frontend · Spring Boot REST API with Spring JDBC · MySQL database. No Docker required.

## 1. Install prerequisites (one time)

- Visual Studio Code
- JDK 17 or newer compatible JDK (JDK 17 is the tested language target)
- Apache Maven 3.9.x
- Node.js 22 LTS with npm
- MySQL Server 8.4 (MySQL Workbench is optional but convenient)

On Windows, make sure the installers add Java, Maven, and Node to PATH. Open a new terminal and check `java -version`, `mvn -version`, and `node -v`. VS Code's Java extension is not a replacement for a local JDK; these tasks also require Maven on PATH.

## 2. Open the project

Extract the ZIP and use **File → Open Folder** to open the `byte-bazaar` folder that contains `.vscode`, `backend`, and `frontend`. Install the recommended Java, Spring Boot, and Prettier extensions when prompted. Allow the Java extension to finish importing the Maven project.

## 3. Configure local MySQL

Start the MySQL service. In MySQL Workbench, connect as an administrator, open `database/setup.sql`, replace `CHANGE_ME` with your chosen password, and execute the script. It creates the `byte_bazaar` database and a database-specific application user. Do not run the application as the MySQL root user.

Copy `backend/config/application-local.example.properties` to `backend/config/application-local.properties`. Replace `CHANGE_ME` with the same password. This real configuration file is ignored by Git. MySQL defaults to localhost port 3306; adjust the connection URL if your installation uses another port.

The setup SQL creates the database and user only. Spring Boot automatically runs the Flyway table migration and adds sample listings on first startup. Existing databases keep their records. Flyway applies the new V2 migration on startup to add admin and auction fields.

## 4. Install frontend dependencies

In VS Code select **Terminal → Run Task → Frontend: install**. Wait for it to finish. Alternatively:

```sh
cd frontend
npm ci
```

## 5. Start the application

Select **Terminal → Run Task → Start Byte Bazaar**. Two terminal tasks start in parallel:

- Spring Boot API: http://localhost:18080
- React application: **http://localhost:5173**

Wait for the backend's “Started Application” message, then open the React URL and create an account. If the frontend opens before the API is ready, refresh it after the backend starts. Data is stored in your local MySQL database.

To stop, use **Terminal → Terminate Task** for both tasks, or press Ctrl+C in each terminal. MySQL runs independently as a local service.

### Manual terminal commands

Open two VS Code terminals. In the first:

```sh
cd backend
mvn spring-boot:run
```

In the second:

```sh
cd frontend
npm run dev
```

### Debugging with F5

For Java breakpoints, start only the frontend task, then select **Debug Spring Boot API** in Run and Debug and press F5. Do not also run the Backend: start task, because both would try to use port 8080. With the frontend task running, **Debug Byte Bazaar** starts the API debugger and Chrome together. The standalone **Debug React in Chrome** profile works with both servers already running.

## Project organization

- `backend/src/main/java/com/bytebazaar/*Controller.java`: HTTP routes grouped by accounts, listings, orders/bookings, and community.
- `MarketplaceService.java` and `AdminService.java`: transactional business rules.
- `MarketplaceRepository.java`: parameterized SQL, row mappings, and generated IDs using Spring's `JdbcTemplate`. Models are plain Java classes. The backend does not depend on JPA or Hibernate ORM.
- `Requests.java`: validated API request records.
- `ApiExceptionHandler.java`: shared API error responses.
- Model files and `Security.java`: persisted data models and session/CSRF security.
- `backend/src/main/resources/db/migration`: versioned MySQL schema and seed content.
- `frontend/src/App.jsx`: page state and orchestration.
- `frontend/src/components`: hero, footer, and marketplace dialogs.
- `frontend/src/lib`: API transport and currency formatting.
- `.vscode`: tasks, debugger settings, and extension recommendations.
- `tests/smoke.py`: integration checks against the running local stack.

The frontend proxies `/api` to the Spring Boot API, keeping browser cookies and CSRF requests on the same origin. Call the application through port 5173 during development. The dev servers bind to loopback for local use.

## Included features

Marketplace search and filters; accounts; seller listing creation; shopping bag and atomic demo checkout; order history; auction bids with closing-time checks; service requests; community topics and replies. Passwords are hashed with BCrypt. MySQL uses Flyway migrations and database relationships.

## Prototype boundaries

Checkout creates demo records and reserves stock; it does not charge money. Digital files/licenses are not delivered. Bookings are requests rather than confirmed reservations. Admins finalize auctions and record the highest bidder; automatic charges and fulfillment are not included. Messaging, reviews, seller editing, MFA, refunds, NFTs, and recommendations remain future work. This is an MVP, not a production-ready marketplace.

## Set up and use the admin account

On backend startup, the application provisions **admin@bytebazaar.com** with password **adminadmin123**. The database stores a BCrypt hash. Sign in with this account to access the administrator dashboard. Existing administrator accounts retain their current password; startup does not reset passwords. If this email is already a customer account, provisioning stops instead of silently granting access.

Override `bytebazaar.admin.email` and `bytebazaar.admin.password` in your local configuration to use different bootstrap credentials.

## Checks and formatting

Frontend: `npm run build`, `npm run format:check`, or `npm run format` from `frontend`. Backend: `mvn verify` from `backend`. Integration: with both servers and MySQL running, execute `py tests/smoke.py` on Windows or `python3 tests/smoke.py` elsewhere. Add `--admin` to check admin access, moderation, and auction controls. The script creates development test records.

See `VERIFICATION.md` for the checks actually run here.

## Troubleshooting

- `mvn` or `java` not recognized: check PATH and JAVA_HOME, then restart VS Code.
- Access denied by MySQL: verify the local properties password matches the MySQL user, and that MySQL is running.
- Unknown database: execute `database/setup.sql` as an administrator first.
- Port 8080 in use: stop the old API/debug session. Port 5173 in use: stop the old frontend task.
- Missing backend configuration: ensure the real properties file is inside `backend/config`, not only the example file.
- Dependencies cannot download: check your network/proxy configuration. No Docker image or container is needed.


## Listing pictures, reports, and analytics

- Sellers may choose up to six JPEG/PNG pictures when creating a sale or auction listing. Open an existing listing to add or remove pictures; administrators can also manage pictures under Storefront and Auctions. Each file must be no larger than 5 MB and 20 megapixels. Pictures are stored in MySQL, not on a temporary filesystem. Back up `listing_photos` with your database. Set MySQL `max_allowed_packet` to at least 16 MB if your server uses a smaller limit.
- Administrator dashboard → **Reports** offers sales orders, daily revenue analytics, auction results, and administrator audit reports. Choose the inclusive UTC date range, generate a report, then Print, Export CSV, or Export PDF. Browser printing also supports Save as PDF. Exports contain the entire selected date range, not only a visible page.
- Analytics show demo order totals, counts, and averages. **Collected revenue remains $0** because checkout does not process payments. Winning auction bids appear separately in auction reports and are not counted as order revenue. Auction date filters use scheduled closing dates, not the time the administrator clicked Close.
- The audit trail starts with this upgrade and records successful administrator listing creation, hiding/restoring listings/topics/replies, auction start/close/cancel, photo additions/removals, and report viewing/export. It includes actor ID/email, UTC time, action, and target. It does not reconstruct past changes or log failed sign-in attempts. Audit records cannot be edited or deleted through the API, but database administrators still control the underlying database.
- Migration `V3__photos_and_audit.sql` runs automatically on backend startup. Keep your existing local configuration and database; do not rerun initial setup or reset tables.
- CSV output protects spreadsheet formula prefixes and quotes embedded commas, quotes, and newlines. Downloaded PDFs use a built-in font and replace characters outside printable ASCII with `?`; use browser Print → Save as PDF for full Unicode text.

### Additional checks

From `backend`, run `mvn test` for the H2-backed photo ownership, report authorization, date boundaries, aggregation, audit insertion, CSV escaping, and PDF pagination checks. These supplement `tests/smoke.py --admin` against your running local MySQL stack; H2 does not replace MySQL integration testing.

## Modern storefront, checkout and invoices

The storefront uses a restrained navy, blue and white design with a responsive checkout screen. New customers must supply first name, last name, email, phone, password and a complete shipping address.

Checkout collects contact, shipping and billing details, offers standard ($7.99) or express ($19.99) shipping, and displays a server-calculated total. Shipping is charged once per checkout containing hardware; digital-only orders have no shipping charge. Each order preserves its address, contact, delivery and price snapshot. Flyway migration V4 adds these fields without deleting existing data.

After checkout, choose **Print invoice / Save as PDF**. You can reopen the complete checkout invoice from **Your orders → Print invoice**. Older orders show an address-unavailable message where details were never captured.

Checkout remains a demo: no payment gateway, payment collection, tax calculation or carrier fulfillment is connected. Invoices are marked unpaid. Restart the backend to apply V4 and provision the requested admin, then restart the frontend.

Validation for this update: frontend production build passed. Backend and MySQL integration tests could not be run in the editing environment because Maven is unavailable. Updated `tests/smoke.py` covers shipping totals and persisted invoice details when run against the local stack.

## Storefront and forum organization

The storefront now has a wide search bar, department navigation, category sidebar, product cards, inventory filters and price sorting. **Items for sale** contains physical and digital products only; **Auctions** and **Services** have their own catalogs. Auctions show closing times; services open booking requests. Existing account, checkout, invoices, photos, administration and reports remain available.

Product departments include PC Components, Storage, Computers & Laptops, Peripherals, Networking, and Software & Digital. Each has selectable subcategories. Services have their own support, development/design, and consulting/training categories. Both storefront and administrator listing forms require a matching category and subcategory.

Community is now a forum directory with five groups and 18 subforums:

- Community Hub: General Discussion, Introductions, Tech News, Site Feedback.
- Builds & Troubleshooting: Build Planning, Troubleshooting, Build Logs & Showcases.
- Computer Hardware: Processors & Motherboards, Graphics Cards, Memory & Storage, Cooling & Cases, Peripherals.
- Software & Development: Operating Systems, Programming, Apps & Tools.
- Gaming & Networking: PC Gaming, Networking & Security, Home Servers.

Open a subforum to see its topics, choose a topic to read/reply, and use the breadcrumbs or Back buttons to return. Forum-wide and subforum searches, topic sorting, counts and latest activity use actual visible discussion data. Hidden replies do not contribute to public counts. New topics require a category/subforum and support up to 5,000 characters; replies retain the 255-character limit.

**Updating an existing installation:** replace the source, run `npm ci` in `frontend`, and restart both servers. Spring Boot automatically applies Flyway V5. It adds taxonomy columns, maps existing listings to suitable departments/subcategories (unclassified hardware goes to PC Components → Other Components), and places existing topics in Community Hub → General Discussion. It retains the existing records. Do not rerun the database setup script or edit previously applied migration files.

`backend/src/main/resources/taxonomy.json` is the shared category definition imported by React and read by the API. The backend rejects mismatched categories/subcategories. Changing this tree later also requires migrating stored values to preserve their discoverability.

Design references: [Newegg](https://www.newegg.com/) for retail navigation and product hierarchy; [Linus Tech Tips Forums](https://linustechtips.com/) for grouped forum boards, topic lists and recent activity. Byte Bazaar retains its own branding and content.

### Validation for this layout update

From `frontend`, run `npm test`, `npm run build` and `npm run format:check`. DOM integration checks use mocked API responses and cover section separation, parent/child filtering, search, sort, stock filtering, checkout/invoices, forum navigation, and category payloads. These checks and the production build passed in the editing environment. They do not verify visual rendering in a browser or database behavior.

From `backend`, run `mvn test` for the existing feature tests and new taxonomy validation / forum-persistence checks. Run `python tests/smoke.py` against the started MySQL/API/frontend stack for migration-integrated behavior (add `--admin` for admin checks). Backend/MySQL tests and full browser visual checks could not run in the editing environment: Maven/JDK compilation tools were unavailable and local Chromium startup was blocked.

## Usernames, avatars and forum photos

Signup now requires a unique public username (3–32 characters, starting with a letter, followed by letters, numbers or underscores). Usernames are unique regardless of capitalization. Customers still sign in with their email/password. Forum authors and recent activity show usernames instead of customers' real names.

An avatar is optional during signup. Open **Account & orders → Forum profile** to change your username, upload/replace an avatar, or remove it. Username/avatar changes apply to existing topics and replies. Avatars accept JPEG or PNG up to 2 MB / 4 megapixels and are cropped to 256 × 256 pixels.

Topics and replies accept up to six JPEG/PNG photos each (5 MB / 20 megapixels per image). Choose photos while composing, or open an existing post and choose **Add photos to this post**. Authors can upload and remove their own photos; administrators can manage photos on visible posts. Open a photo to view the full image. Hidden topics/replies do not expose their attachments. Photo limits are enforced on the server, including concurrent uploads.

Uploads are decoded and re-encoded before storage, which discards supplied image metadata. Avatars and forum attachments are stored in MySQL and survive application restarts. If a text post succeeds but a photo upload fails, the UI reports that the post was saved and offers an upload retry from the existing post to avoid duplicate text posts.

Restart the API to apply Flyway **V6**. Existing accounts automatically receive unique usernames such as `member12`; account owners can choose a new one from their profile. The migration replaces historical forum author snapshots with these usernames. Customer contact names remain in account and checkout data.

Validation: `npm test` includes signup username/avatar, profile editing, avatar display/removal/replacement, topic/reply photo upload flows, image-picker validation and owner-only controls using mocked APIs. `ProfilePhotoTest` adds backend image validation, username rules/uniqueness, profile persistence, attachment ownership and hidden-post tests. Updated `tests/smoke.py` covers usernames, profile changes and multipart image uploads against the running stack. Backend/live database tests could not run in the editing environment because Maven is unavailable.

## Repeated port 8080 conflict: use the Windows launcher

After extracting this update, retain your existing `backend/config/application-local.properties` database settings. Run `npm ci` in `frontend`, then double-click `Start-Byte-Bazaar.cmd` in the main `byte-bazaar` folder (or run `node scripts/start.mjs`). In VS Code, the **Start Byte Bazaar** task uses the same launcher. Do not start a second backend task or debugger at the same time.

The launcher finds an available API port starting at 18080 and a website port starting at 5173. It passes the API port as an explicit Spring Boot application argument and supplies the matching proxy target to Vite. Existing `SERVER_PORT`, local port properties and the default 8080 setting cannot override that application argument. It prints the exact website URL to open. Wait for Spring Boot's Started Application message, then load that URL. If you loaded the frontend before the backend was ready, reload after the backend starts.

The ordinary backend task and Java debugger explicitly use 18080; standalone Vite defaults to the same API port. If 18080 is occupied, use the launcher, which selects another available port. It does not kill the application occupying 8080. Ctrl+C stops the processes started by the launcher.

For an immediate backend-only override from `backend`, use:

```powershell
mvn spring-boot:run "-Dspring-boot.run.arguments=--server.port=18080"
```

If a new log still reports 8080 after that exact command, it is coming from a different launch/configuration: stop the VS Code debugger/backend task and run the command in a fresh backend terminal. The launcher must be started from this updated package rather than a previous extracted copy.
