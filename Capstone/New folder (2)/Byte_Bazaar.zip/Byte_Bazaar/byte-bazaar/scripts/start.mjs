import net from 'node:net';
import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const windows=process.platform==='win32';
const children=new Set();
let stopping=false;
function start(command,args,cwd,env={}){
 const child=spawn(command,args,{cwd,stdio:'inherit',shell:windows,env:{...process.env,...env}});
 children.add(child);
 child.once('error',error=>{console.error(`Could not start ${command}: ${error.message}. Check that Node, npm and Maven are on PATH.`);stop(1);});
 child.once('exit',code=>{children.delete(child);if(!stopping)stop(code||1);});
 return child;
}
function stop(code=0){if(stopping)return;stopping=true;for(const child of children){if(windows)spawn('taskkill',['/pid',String(child.pid),'/T','/F'],{stdio:'ignore'});else child.kill('SIGTERM');}process.exitCode=code;}
process.on('SIGINT',()=>stop(0));process.on('SIGTERM',()=>stop(0));
async function freePort(first){
 for(let port=first;port<first+100;port++){
  const available=await new Promise((resolve,reject)=>{const server=net.createServer();server.once('error',e=>{if(e.code==='EADDRINUSE'||e.code==='EACCES')resolve(false);else reject(e);});server.listen({port,host:'127.0.0.1',exclusive:true},()=>server.close(()=>resolve(true)));});
  if(available)return port;
 }
 throw Error(`No available local port between ${first} and ${first+99}.`);
}
try{
 if(!existsSync(new URL('../frontend/node_modules/vite',import.meta.url))){
  console.log('Frontend dependencies are missing. Run npm ci in frontend, then start again.');process.exitCode=1;
 }else{
  const apiPort=await freePort(18080),webPort=await freePort(5173);
  console.log(`\nByte Bazaar API: http://127.0.0.1:${apiPort}\nByte Bazaar website: http://127.0.0.1:${webPort}\nUsing an explicit backend port override; settings for port 8080 cannot override it.\nPress Ctrl+C in this window to stop this launch.\n`);
  start('mvn',['spring-boot:run',`-Dspring-boot.run.arguments=--server.port=${apiPort}`],fileURLToPath(new URL('../backend',import.meta.url)));
  start('npm',['run','dev','--','--host','127.0.0.1','--port',String(webPort)],fileURLToPath(new URL('../frontend',import.meta.url)),{BYTEBAZAAR_API_URL:`http://127.0.0.1:${apiPort}`});
  console.log('Wait for Spring Boot to report Started Application before opening the website.');
 }
}catch(error){console.error(error.message);stop(1);}
